package at.redi2go.photonics.common.mixins.iris.pipeline.sampler;

import net.minecraft.class_12134;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_12134.class)
public interface GlSamplerAccessor {
    @Accessor
    int getId();
}
