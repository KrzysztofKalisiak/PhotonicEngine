package at.redi2go.photonics.common.meshing.impl;

import at.redi2go.photonics.api.mc.Id;
import at.redi2go.photonics.common.mixins.meshing.OuterWrappedRenderTypeAccessor;
import at.redi2go.photonics.common.mixins.meshing.RenderSetupAccessor;
import at.redi2go.photonics.common.mixins.meshing.RenderTypeAccessor;
import at.redi2go.photonics.core.rendering.world.bakery.BlockBuilder;
import net.irisshaders.iris.layer.OuterWrappedRenderType;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.jspecify.annotations.NonNull;

public class BlockBuilderBufferSource extends class_4597.class_4598 {
    private BlockBuilder blockBuilder;

    public BlockBuilderBufferSource() {
        super(null, null);
    }

    public void setBlockBuilder(BlockBuilder blockBuilder) {
        this.blockBuilder = blockBuilder;
    }

    @Override
    public @NonNull class_4588 method_73477(@NonNull class_1921 renderType) {
        if (renderType instanceof OuterWrappedRenderType wrapped)
            renderType = ((OuterWrappedRenderTypeAccessor) wrapped).getWrapped();

        class_12247 renderSetup = ((RenderTypeAccessor) renderType).getState();
        var textures = ((RenderSetupAccessor) (Object) renderSetup).getTextureSetup();
        var sampler0 = textures.get("Sampler0");

        if (sampler0 == null) return EmptyVertexConsumer.INSTANCE;

        blockBuilder.useAtlas((Id) (Object) sampler0.getLocation());

        return (class_4588) blockBuilder;
    }

    @Override
    public void method_37104() {

    }

    @Override
    public void method_22993() {

    }

    @Override
    public void method_22994(@NonNull class_1921 renderType) {

    }
}
