package at.redi2go.photonics.common.mixins.meshing;

import net.minecraft.class_12247;
import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1921.class)
public interface RenderTypeAccessor {
    @Accessor
    class_12247 getState();
}
