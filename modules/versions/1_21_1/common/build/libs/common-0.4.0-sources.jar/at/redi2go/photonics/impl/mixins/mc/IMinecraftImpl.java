package at.redi2go.photonics.impl.mixins.mc;

import at.redi2go.photonics.api.mc.Minecraft;
import at.redi2go.photonics.api.mc.world.level.ILevel;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value = Minecraft.class)
public interface IMinecraftImpl {
    @Overwrite
    static void schedule(Runnable runnable) {
        net.minecraft.class_310.method_1551()
                .execute(runnable);
    }

    @Overwrite
    static @Nullable ILevel getLevel() {
        return (ILevel) net.minecraft.class_310.method_1551()
                .field_1687;
    }

    @Overwrite
    static Vector3d getCameraPos() {
        class_243 position = net.minecraft.class_310.method_1551()
                .field_1773
                .method_19418()
                .method_19326();

        return new Vector3d(position.field_1352, position.field_1351, position.field_1350);
    }

    @Overwrite
    static int getRenderDistance() {
        return net.minecraft.class_310.method_1551()
                .field_1690
                .method_38521();
    }
}
