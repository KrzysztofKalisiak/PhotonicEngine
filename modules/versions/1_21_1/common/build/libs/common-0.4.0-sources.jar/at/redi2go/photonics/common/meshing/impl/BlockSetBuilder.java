package at.redi2go.photonics.common.meshing.impl;

import com.google.common.collect.ImmutableSet;
import java.util.Set;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

public class BlockSetBuilder {
    private final ImmutableSet.Builder<class_2248> blocks = ImmutableSet.builder();

    public BlockSetBuilder addBlock(class_2248 block) {


        blocks.add(block);

        return this;
    }

    public BlockSetBuilder addTag(class_6862<class_2248> blockTagKey) {
        class_7923.field_41175.method_46733(blockTagKey)
                .ifPresent((blocks) ->
                        blocks.forEach(holder ->
                                this.blocks.add(holder.comp_349())));

        return this;
    }

    public Set<class_2248> build() {
        return blocks.build();
    }
}
