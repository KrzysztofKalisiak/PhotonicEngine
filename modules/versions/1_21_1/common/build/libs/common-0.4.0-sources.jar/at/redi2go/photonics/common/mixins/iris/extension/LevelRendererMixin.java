package at.redi2go.photonics.common.mixins.iris.extension;

import at.redi2go.photonics.common.iris.IrisUtil;
import at.redi2go.photonics.core.iris.PhotonicsExtension;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_4184;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Inject(
            method = "renderLevel",
            at = @At("HEAD"),
            order = 900
    )
    public void renderLevel(
            class_9922 graphicsResourceAllocator,
            class_9779 deltaTracker,
            boolean bl,
            class_4184 camera,
            Matrix4f matrix4f,
            Matrix4f matrix4f2,
            Matrix4f matrix4f3,
            GpuBufferSlice gpuBufferSlice,
            Vector4f vector4f,
            boolean bl2,
            CallbackInfo ci
    ) {
        IrisUtil.getPhotonics().ifPresent(PhotonicsExtension::onFrameBegin);
    }
}
