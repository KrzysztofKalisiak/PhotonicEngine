package at.redi2go.photonics.common;

import net.minecraft.class_778;

public interface BlockRenderDispatcherExt {
    class_778 photonics$modelBlockRenderer();
}
