package at.redi2go.photonics.common.mixins.meshing;

import at.redi2go.photonics.api.gpu.textures.TextureUsage;
import net.minecraft.class_10537;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(class_10537.class)
public abstract class ReloadableTextureMixin {
    @ModifyConstant(method = "doLoad", constant = @Constant(intValue = 5))
    private int modifyUsage(int constant) {
        return constant | TextureUsage.COPY_SRC;
    }
}
