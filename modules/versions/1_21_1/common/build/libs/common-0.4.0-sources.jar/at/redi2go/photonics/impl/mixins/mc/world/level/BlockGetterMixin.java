package at.redi2go.photonics.impl.mixins.mc.world.level;

import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.IBlockGetter;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.api.mc.world.level.block.IBlockEntity;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1922.class)
public interface BlockGetterMixin extends IBlockGetter {
    @Shadow class_2680 getBlockState(class_2338 pos);

    @Shadow class_2586 getBlockEntity(class_2338 pos);

    @Override
    default IBlockState ph$getBlockState(IBlockPos pos) {
        return (IBlockState) getBlockState((class_2338) pos);
    }

    @Override
    default @Nullable IBlockEntity ph$getBlockEntity(IBlockPos pos) {
        return (IBlockEntity) getBlockEntity((class_2338) pos);
    }
}
