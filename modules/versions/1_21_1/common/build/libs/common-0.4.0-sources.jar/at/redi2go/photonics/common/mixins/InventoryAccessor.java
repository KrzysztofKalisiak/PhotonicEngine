package at.redi2go.photonics.common.mixins;

import net.minecraft.class_10630;
import net.minecraft.class_1661;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1661.class)
public interface InventoryAccessor {
    @Accessor
    class_10630 getEquipment();
}
