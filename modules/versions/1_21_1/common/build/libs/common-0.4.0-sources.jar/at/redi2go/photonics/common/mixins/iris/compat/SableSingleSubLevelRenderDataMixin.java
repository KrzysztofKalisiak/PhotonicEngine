package at.redi2go.photonics.common.mixins.iris.compat;

import at.redi2go.photonics.common.iris.IrisBlockMaterialBridge;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4588;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = "dev.ryanhcode.sable.sublevel.render.vanilla.VanillaSingleSubLevelRenderData", remap = false)
public abstract class SableSingleSubLevelRenderDataMixin {
    @Shadow(remap = false)
    private class_2680 singleBlockState;

    @Shadow(remap = false)
    private class_2338 singleBlockPos;

    @Unique
    private boolean photonics$materialContextActive;

    @Inject(method = "renderSingleBlock", at = @At("HEAD"), require = 0, remap = false)
    private void photonics$beginIrisMaterialContext(
            class_1921 layer,
            class_4588 consumer,
            Matrix4f modelView,
            double cameraX,
            double cameraY,
            double cameraZ,
            CallbackInfo ci
    ) {
        this.photonics$materialContextActive = IrisBlockMaterialBridge.begin(
                consumer,
                this.singleBlockState,
                this.singleBlockPos,
                "sable-single"
        );
    }

    @Inject(method = "renderSingleBlock", at = @At("RETURN"), require = 0, remap = false)
    private void photonics$endIrisMaterialContext(
            class_1921 layer,
            class_4588 consumer,
            Matrix4f modelView,
            double cameraX,
            double cameraY,
            double cameraZ,
            CallbackInfo ci
    ) {
        IrisBlockMaterialBridge.end(consumer, this.photonics$materialContextActive);
        this.photonics$materialContextActive = false;
    }
}
