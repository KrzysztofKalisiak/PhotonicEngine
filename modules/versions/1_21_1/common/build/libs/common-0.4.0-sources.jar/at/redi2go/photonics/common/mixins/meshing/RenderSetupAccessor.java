package at.redi2go.photonics.common.mixins.meshing;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_12247;

@Mixin(class_12247.class)
public interface RenderSetupAccessor {
    @Accessor("textures")
    Map<String, TextureSetupAccessor> getTextureSetup();
}
