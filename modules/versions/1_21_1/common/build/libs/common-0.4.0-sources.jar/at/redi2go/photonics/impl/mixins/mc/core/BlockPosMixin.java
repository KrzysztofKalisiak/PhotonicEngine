package at.redi2go.photonics.impl.mixins.mc.core;

import at.redi2go.photonics.api.mc.core.IBlockPos;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import org.joml.Vector3i;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2338.class)
public abstract class BlockPosMixin extends class_2382 implements IBlockPos {
    private BlockPosMixin(int i, int j, int k) {
        super(i, j, k);
    }

    @Override
    public int ph$x() {
        return method_10263();
    }

    @Override
    public int ph$y() {
        return method_10264();
    }

    @Override
    public int ph$z() {
        return method_10260();
    }

    @Override
    public IBlockPos ph$offset(int x, int y, int z) {
        return (IBlockPos) method_34592(x, y, z);
    }
}
