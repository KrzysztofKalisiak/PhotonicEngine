package at.redi2go.photonics.common.mixins;

import at.redi2go.photonics.common.BlockRenderDispatcherExt;
import net.minecraft.class_776;
import net.minecraft.class_778;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_776.class)
public abstract class BlockRenderDispatcherMixin implements BlockRenderDispatcherExt {
    @Shadow
    @Final
    private class_778 modelRenderer;

    @Override
    public class_778 photonics$modelBlockRenderer() {
        return modelRenderer;
    }
}
