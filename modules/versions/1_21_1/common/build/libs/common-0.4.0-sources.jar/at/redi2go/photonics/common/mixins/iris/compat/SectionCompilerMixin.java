package at.redi2go.photonics.common.mixins.iris.compat;

import at.redi2go.photonics.common.iris.IrisBlockMaterialBridge;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import net.minecraft.class_9810;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_9810.class)
public class SectionCompilerMixin {
    @WrapOperation(
            method = "compile",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/block/BlockRenderDispatcher;renderBatched(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/BlockAndTintGetter;Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;ZLnet/minecraft/util/RandomSource;)V"
            )
    )
    private void photonics$provideIrisMaterialContext(
            class_776 dispatcher,
            class_2680 blockState,
            class_2338 blockPos,
            class_1920 level,
            class_4587 poseStack,
            class_4588 consumer,
            boolean checkSides,
            class_5819 random,
            Operation<Void> original
    ) {
        boolean active = IrisBlockMaterialBridge.begin(consumer, blockState, blockPos, "vanilla-section");
        try {
            original.call(dispatcher, blockState, blockPos, level, poseStack, consumer, checkSides, random);
        } finally {
            IrisBlockMaterialBridge.end(consumer, active);
        }
    }
}
