package at.redi2go.photonics.common.iris;

import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.IBlock;
import at.redi2go.photonics.api.mc.world.level.ILevelReader;
import at.redi2go.photonics.core.config.Variable;
import at.redi2go.photonics.core.config.lights.block.LightBlock;
import at.redi2go.photonics.core.config.lights.predicate.LightPredicate;
import at.redi2go.photonics.core.iris.AbstractIrisPackLights;
import net.irisshaders.iris.shaderpack.ShaderPack;
import net.irisshaders.iris.shaderpack.materialmap.BlockEntry;
import net.irisshaders.iris.shaderpack.materialmap.TagEntry;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public class IrisPackLightsImpl extends AbstractIrisPackLights {
    private ShaderPack shaderPack;
    private Set<class_2248> usedBlocks;

    public void setShaderPack(ShaderPack pack) {
        this.shaderPack = pack;
        defines.setOwner(this);
    }

    private void loadUsedBlocks() {
        if (usedBlocks != null) return;

        usedBlocks = new HashSet<>();
        final var idMap = shaderPack.getIdMap();

        for (var entry : idMap.getBlockProperties().values()) {
            for (var blockId : entry) {
                class_2960 identifier = class_2960.method_60655(blockId.id().getNamespace(), blockId.id().getName());

                class_7923.field_41175.method_10223(identifier)
                        .ifPresent(e -> usedBlocks.add(e.comp_349()));
            }
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> Optional<T> getValue(Variable.Type<T> type, String name) {
        if (type == LightBlock.TYPE) {
            try {
                final var idMap = shaderPack.getIdMap();

                int id = Integer.parseInt(name);

                var blocks = idMap.getBlockProperties().getOrDefault(id, null);
                var tags = idMap.getTagEntries().getOrDefault(id, null);

                if (blocks == null && tags == null)
                    return Optional.empty();

                return (Optional<T>) Optional.of(new ShaderLightBlock(blocks, tags));
            } catch (NumberFormatException e) {
                return Optional.empty();
            }
        }

        return defines.getValue(type, name);
    }

    private class ShaderLightBlock implements LightBlock {
        private final @Nullable List<BlockEntry> blocks;
        private final @Nullable List<TagEntry> tags;

        private ShaderLightBlock(
                @Nullable List<BlockEntry> blocks,
                @Nullable List<TagEntry> tags
        ) {
            this.blocks = blocks;
            this.tags = tags;
        }

        @Override
        public List<LightPredicate> listPredicates() {
            loadUsedBlocks();
            final var out = new ArrayList<LightPredicate>();

            if (blocks != null) {
                for (var block : blocks) {
                    var id = class_2960.method_60655(block.id().getNamespace(), block.id().getName());
                    class_7923.field_41175.method_10223(id)
                            .ifPresent(e -> {
                                out.add(
                                        new ShaderPredicate(
                                                e.comp_349(),
                                                block.propertyPredicates()
                                        )
                                );
                            });
                }
            }

            if (tags != null) {
                for (var tag : tags) {
                    var id = class_2960.method_60655(tag.id().getNamespace(), tag.id().getName());
                    var key = class_6862.method_40092(class_7924.field_41254, id);

                    class_7923.field_41175.method_46733(key)
                            .ifPresent(blocks -> {
                                for (var block : blocks) {
                                    if (usedBlocks.contains(block.comp_349())) continue;

                                    out.add(new ShaderPredicate(
                                            block.comp_349(),
                                            tag.propertyPredicates()
                                    ));
                                }
                            });
                }
            }

            return out;
        }

        public @Nullable List<BlockEntry> blocks() {
            return blocks;
        }

        public @Nullable List<TagEntry> tags() {
            return tags;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj == null || obj.getClass() != this.getClass()) return false;
            var that = (ShaderLightBlock) obj;
            return Objects.equals(this.blocks, that.blocks) &&
                    Objects.equals(this.tags, that.tags);
        }

        @Override
        public int hashCode() {
            return Objects.hash(blocks, tags);
        }

        @Override
        public String toString() {
            return "ShaderLightBlock[" +
                    "blocks=" + blocks + ", " +
                    "tags=" + tags + ']';
        }

    }

    private record ShaderPredicate(
            class_2248 mcBlock,
            Map<String, String> vagueProperties
    ) implements LightPredicate {
        public ShaderPredicate {
            Objects.requireNonNull(mcBlock, "block was null");
            Objects.requireNonNull(vagueProperties, "vagueProperties was null");
        }

        @Override
        public IBlock block() {
            return (IBlock) mcBlock;
        }

        @Override
        public int priority() {
            return LightPredicate.NORMAL_PRIORITY;
        }

        @Override
        public boolean test(IBlockPos pos, ILevelReader levelReader) {
            final class_2680 state = (class_2680) levelReader.ph$getBlockState(pos);
            if (!state.method_27852(mcBlock)) return false;

            for (Map.Entry<String, String> entry : vagueProperties.entrySet()) {
                final class_2769<?> property = mcBlock.method_9595().method_11663(entry.getKey());
                if (property == null) return false;

                final var value = property.method_11900(entry.getValue()).orElse(null);
                if (value == null) return false;

                if (!value.equals(state.method_11654(property))) return false;
            }

            return true;
        }
    }

}
