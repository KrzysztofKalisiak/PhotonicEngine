package at.redi2go.photonics.impl.mixins.mc.world.level;

import at.redi2go.photonics.api.mc.Id;
import at.redi2go.photonics.api.mc.world.level.IBlock;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.api.mc.world.level.block.state.IStateDefinition;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2248.class)
@SuppressWarnings("unchecked")
public abstract class BlockMixin implements IBlock {
    @Shadow
    public abstract class_2689<class_2248, class_2680> getStateDefinition();

    @Shadow
    public abstract class_2680 defaultBlockState();

    @Override
    public Id ph$id() {
        return (Id) (Object) class_7923.field_41175.method_10221((class_2248) (Object) this);
    }

    @Override
    public IStateDefinition<IBlock, IBlockState> ph$stateDefinition() {
        return (IStateDefinition<IBlock, IBlockState>) getStateDefinition();
    }

    @Override
    public IBlockState ph$defaultBlockState() {
        return (IBlockState) defaultBlockState();
    }
}
