package at.redi2go.photonics.common.meshing;

import at.redi2go.photonics.core.rendering.world.block.VoxelColor;
import java.util.List;
import net.minecraft.class_10889;
import net.minecraft.class_1920;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_324;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_777;

public class SimpleMeshState implements McMeshState {
    private static final class_2350[] DIRECTIONS = class_2350.values();
    private static final class_324 BLOCK_COLORS = class_310.method_1551().method_1505();

    private final class_2248 block;
    private final int blockId;
    private List<class_10889> blockModel;

    private long hashCode = 0;

    public SimpleMeshState(
            class_2248 block,
            int blockId,
            List<class_10889> blockModel
    ) {
        this.block = block;
        this.blockId = blockId;
        this.blockModel = blockModel;
    }

    public void computeHash(
            HashStorage hashStorage,
            class_2680 blockState,
            class_2338 blockPos,
            class_1920 blockAndTintGetter
    ) {
        hashStorage.lastTintIndex = Integer.MIN_VALUE;
        hashStorage.lastTint = VoxelColor.WHITE;

        long hashCode = blockId;

        for (var part : blockModel) {
            for (var direction : DIRECTIONS) {
                hashCode = hashCode * 31 + hashPart(
                        hashStorage,
                        blockState,
                        blockPos,
                        blockAndTintGetter,
                        part.method_68509(direction)
                );
            }

            hashCode = hashCode * 31 + hashPart(
                    hashStorage,
                    blockState,
                    blockPos,
                    blockAndTintGetter,
                    part.method_68509(null)
            );
        }

        this.hashCode = hashCode;
    }

    private static long hashPart(
            HashStorage hashStorage,
            class_2680 blockState,
            class_2338 blockPos,
            class_1920 blockAndTintGetter,
            List<class_777> quads
    ) {
        long hash = 1;

        for (var quad : quads) {
            hash = hash * 31 + hashQuad(
                    hashStorage,
                    blockState,
                    blockPos,
                    blockAndTintGetter,
                    quad
            );
        }

        return hash;
    }

    private static long hashQuad(
            HashStorage hashStorage,
            class_2680 blockState,
            class_2338 blockPos,
            class_1920 blockAndTintGetter,
            class_777 bakedQuad
    ) {
        long hash;

        int tintIndex = bakedQuad.comp_3722();
        if (tintIndex != -1) {
            if (hashStorage.lastTintIndex == tintIndex) {
                hash = hashStorage.lastTint;
            } else {
                int tintColor = BLOCK_COLORS.method_1697(blockState, blockAndTintGetter, blockPos, tintIndex);

                hashStorage.lastTintIndex = tintIndex;
                hashStorage.lastTint = tintColor;
                hash = tintColor;
            }
        } else hash = VoxelColor.WHITE;

        hash = hash * 31 + bakedQuad.comp_5238().hashCode();
        hash = hash * 31 + bakedQuad.comp_5239().hashCode();
        hash = hash * 31 + bakedQuad.comp_5240().hashCode();
        hash = hash * 31 + bakedQuad.comp_5241().hashCode();

        hash = hash * 31 + bakedQuad.comp_5242();
        hash = hash * 31 + bakedQuad.comp_5243();
        hash = hash * 31 + bakedQuad.comp_5244();
        hash = hash * 31 + bakedQuad.comp_5245();

        return hash;
    }

    @Override
    public boolean shouldCache() {
        return true;
    }

    @Override
    public void prepareCacheUse() {
        blockModel = List.of();
    }

    @Override
    public int blockId() {
        return blockId;
    }

    @Override
    public class_3610 fluidState() {
        return class_3612.field_15906.method_15785();
    }

    @Override
    public List<class_10889> blockModel() {
        return blockModel;
    }

    @Override
    public int hashCode() {
        return Long.hashCode(hashCode);
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof SimpleMeshState other && other.hashCode == hashCode && other.block == block && other.blockId == blockId();
    }

    public static class HashStorage {
        private int lastTintIndex = -1;
        private int lastTint = VoxelColor.WHITE;
    }
}
