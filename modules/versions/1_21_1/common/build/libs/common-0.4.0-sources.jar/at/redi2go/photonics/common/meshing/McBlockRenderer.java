package at.redi2go.photonics.common.meshing;

import at.redi2go.photonics.api.mc.Id;
import at.redi2go.photonics.common.BlockRenderDispatcherExt;
import at.redi2go.photonics.common.iris.IrisUtil;
import at.redi2go.photonics.common.meshing.impl.BlockBuilderBufferSource;
import at.redi2go.photonics.common.meshing.impl.BlockSetBuilder;
import at.redi2go.photonics.common.meshing.impl.EmptyBufferSource;
import at.redi2go.photonics.common.meshing.impl.EmptyOutlineBufferSource;
import at.redi2go.photonics.common.meshing.impl.FeatureRendererExt;
import at.redi2go.photonics.core.rendering.world.bakery.BlockBuilder;
import org.joml.Vector3i;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1059;
import net.minecraft.class_10889;
import net.minecraft.class_11658;
import net.minecraft.class_11661;
import net.minecraft.class_11684;
import net.minecraft.class_11954;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import net.minecraft.class_827;

public class McBlockRenderer {
    private static final Id BLOCK_ATLAS = (Id) (Object) class_1059.field_5275;
    private static final Set<class_3611> WHITELISTED_FLUIDS = Set.of(class_3612.field_15908, class_3612.field_15907);

    private final class_5819 randomSource = class_5819.method_43047();
    private final class_776 blockRenderer = class_310.method_1551().method_1541();
    private final class_4587 poseStack = new class_4587();

    private final BlockBuilderBufferSource bufferSource = new BlockBuilderBufferSource();

    private final class_11658 levelRenderState = new class_11658();
    private final class_11661 submitNodeStorage = new class_11661();
    private final class_11684 featureRenderDispatcher = new class_11684(
            submitNodeStorage,
            blockRenderer,
            bufferSource,
            class_310.method_1551().method_72703(),
            EmptyOutlineBufferSource.INSTANCE,
            EmptyBufferSource.INSTANCE,
            class_310.method_1551().field_1772
    );

    private final SimpleMeshState.HashStorage hashStorage = new SimpleMeshState.HashStorage();

    public McBlockRenderer() {
        var featureRenderer = (FeatureRendererExt) featureRenderDispatcher;

        featureRenderer.setRenderShadows(false);
        featureRenderer.setRenderFlames(false);
        featureRenderer.setRenderNametags(false);
        featureRenderer.setRenderText(false);
        featureRenderer.setRenderParticles(false);
    }

    public McMeshState extractMeshState(
            Vector3i blockChunkOffset,
            class_2338 blockPos,
            class_2680 blockState,
            class_1920 blockAndTintGetter
    ) {
        if (blockState.method_26204() == class_2246.field_10613)
            return EmptyMeshState.INSTANCE;

        int blockId = IrisUtil.getBlockId(blockState);
        class_3610 fluidState = blockState.method_26227();

        List<class_10889> parts;
        if (blockState.method_26217() == class_2464.field_11458) {
            parts = new ArrayList<>();

            randomSource.method_43052(blockState.method_26190(blockPos));
            blockRenderer.method_3349(blockState).method_68513(randomSource, parts);
        } else parts = List.of();

        if (blockState.method_31709()) return new DynamicMeshState(blockId, fluidState, parts);
        if (WHITELISTED_FLUIDS.contains(fluidState.method_15772())) return new DynamicMeshState(blockId, fluidState, parts);

        if (parts.isEmpty())
            return EmptyMeshState.INSTANCE;

        var meshState = new SimpleMeshState(blockState.method_26204(), blockId, parts);
        meshState.computeHash(
                hashStorage,
                blockState,
                blockPos,
                blockAndTintGetter
        );

        return meshState;
    }

    public void meshBlock(
            McMeshState meshState,
            Vector3i blockChunkOffset,
            class_2338 pos,
            class_2680 blockState,
            class_1920 blockAndTintGetter,
            BlockBuilder builder
    ) {
        if (meshState == EmptyMeshState.INSTANCE) return;

        builder.useBlockId(meshState.blockId());

        class_3610 fluidState = meshState.fluidState();
        if (!fluidState.method_15769()) {
            submitFluid(
                    pos,
                    blockAndTintGetter,
                    builder,
                    blockState,
                    fluidState
            );
        }

        if (blockState.method_31709()) {
            submitBlockEntity(
                    pos,
                    blockState,
                    blockAndTintGetter,
                    builder
            );
        }

        List<class_10889> parts = meshState.blockModel();
        if (!parts.isEmpty()) {
            submitBlock(
                    pos,
                    blockState,
                    blockAndTintGetter,
                    builder,
                    parts
            );
        }
    }

    private void submitFluid(
            class_2338 blockPos,
            class_1920 blockAndTintGetter,
            BlockBuilder builder,
            class_2680 blockState,
            class_3610 fluidState
    ) {
        if (!WHITELISTED_FLUIDS.contains(fluidState.method_15772())) return;

        builder.useAtlas(BLOCK_ATLAS);
        builder.useOffset(
                -(blockPos.method_10263() & 15),
                -(blockPos.method_10264() & 15),
                -(blockPos.method_10260() & 15)
        );

        blockRenderer.method_3352(blockPos, blockAndTintGetter, (class_4588) builder, blockState, fluidState);
    }

    private void submitBlock(
            class_2338 pos,
            class_2680 blockState,
            class_1920 blockAndTintGetter,
            BlockBuilder builder,
            List<class_10889> parts
    ) {
        builder.useAtlas(BLOCK_ATLAS);
        builder.useOffset(0f, 0f, 0f);

        poseStack.method_22903();

        ((BlockRenderDispatcherExt) blockRenderer)
                .photonics$modelBlockRenderer()
                .method_3373(
                        blockAndTintGetter,
                        parts,
                        blockState,
                        pos,
                        poseStack,
                        (class_4588) builder,
                        false,
                        class_4608.field_21444
                );

        poseStack.method_22909();
    }

    private static final Set<class_2248> FULL_BLOCK_ENTITY_REQUIRED_FOR = new BlockSetBuilder()
            .addBlock(class_2246.field_10432)
            .addBlock(class_2246.field_10208)
            .build();

    private static final Set<class_2248> LEVEL_REQUIRED_FOR = new BlockSetBuilder()
            .addBlock(class_2246.field_10034)
            .build();

    private class_2586 copyBlockEntity(class_2680 blockState) {
        class_2343 entityBlock = (class_2343) blockState.method_26204();
        return entityBlock.method_10123(new class_2338(0, 0, 0), blockState);
    }

    private class_2586 fetchBlockEntity(class_2338 blockPos, class_2680 blockState) {
        try {
            var level = class_310.method_1551().field_1687;
            if (level == null || !level.method_76805(blockPos)) return copyBlockEntity(blockState);

            var chunk = level.method_8500(blockPos);
            return chunk.method_8321(blockPos);
        } catch (Exception e) {
            return copyBlockEntity(blockState);
        }
    }

    private void submitBlockEntity(
            class_2338 blockPos,
            class_2680 blockState,
            class_1920 blockAndTintGetter,
            BlockBuilder builder
    ) {
        builder.useOffset(0f, 0f, 0f);
        bufferSource.setBlockBuilder(builder);

        levelRenderState.method_72913();

        try {
            class_2586 entity = FULL_BLOCK_ENTITY_REQUIRED_FOR.contains(blockState.method_26204()) ?
                    fetchBlockEntity(blockPos, blockState) :
                    copyBlockEntity(blockState);

            if (entity == null) return;

            if (LEVEL_REQUIRED_FOR.contains(blockState.method_26204()))
                entity.method_31662((class_1937) blockAndTintGetter);

            class_827<class_2586, class_11954> renderer =
                    class_310.method_1551().method_31975().method_3550(entity);

            if (renderer == null) return;

            var renderState = renderer.method_74335();
            renderer.method_74331(entity, renderState, 0.8f, levelRenderState.field_63082.field_63078, null);

            poseStack.method_22903();
            renderer.method_3569(renderState, poseStack, submitNodeStorage, levelRenderState.field_63082);
            poseStack.method_22909();

            featureRenderDispatcher.method_73002();
        } finally {
            bufferSource.setBlockBuilder(null);
        }
    }
}
