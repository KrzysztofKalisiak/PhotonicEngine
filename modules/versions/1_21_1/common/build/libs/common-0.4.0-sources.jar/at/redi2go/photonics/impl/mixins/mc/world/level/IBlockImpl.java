package at.redi2go.photonics.impl.mixins.mc.world.level;

import at.redi2go.photonics.api.mc.Id;
import at.redi2go.photonics.api.mc.world.level.IBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

@Mixin(IBlock.class)
@SuppressWarnings({"DataFlowIssue", "unchecked", "rawtypes"})
public interface IBlockImpl {
    @Overwrite
    static Optional<IBlock> fromId(Id id) {
        return (Optional) class_7923.field_41175
                .method_10223((class_2960) (Object) id)
                .map(class_6880.class_6883::comp_349);
    }
}
