package at.redi2go.photonics.impl.mixins.mc.world.level;

import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.ILevel;
import at.redi2go.photonics.api.mc.world.level.chunk.IChunkAccess;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_3568;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1937.class)
public abstract class LevelMixin implements ILevel {
    @Shadow
    public abstract @Nullable class_2791 getChunk(int i, int j, class_2806 chunkStatus, boolean bl);

    @Override
    public @Nullable IChunkAccess ph$getChunkOrNull(int x, int y) {
        return (IChunkAccess) getChunk(x, y, class_2806.field_12803, false);
    }

    @Shadow
    public abstract class_3568 getLightEngine();

    @Override
    public int ph$getSkylightValue(IBlockPos pos) {
        var lightEngine = getLightEngine();
        var layerListener = lightEngine.method_15562(class_1944.field_9284);

        return layerListener.method_15543((class_2338) pos);
    }
}
