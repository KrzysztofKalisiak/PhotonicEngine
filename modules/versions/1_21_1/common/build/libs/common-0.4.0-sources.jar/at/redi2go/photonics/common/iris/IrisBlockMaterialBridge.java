package at.redi2go.photonics.common.iris;

import at.redi2go.photonics.core.Photonics;
import net.irisshaders.iris.shaderpack.materialmap.WorldRenderingSettings;
import net.irisshaders.iris.vertices.BlockSensitiveBufferBuilder;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4588;
import net.minecraft.class_7923;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class IrisBlockMaterialBridge {
    private static final Set<String> BRIDGE_LOGGED = ConcurrentHashMap.newKeySet();
    private static final Set<String> EMISSIVE_LOGGED = ConcurrentHashMap.newKeySet();

    private IrisBlockMaterialBridge() {
    }

    public static boolean begin(
            class_4588 consumer,
            class_2680 blockState,
            class_2338 blockPos,
            String renderPath
    ) {
        if (!(consumer instanceof BlockSensitiveBufferBuilder builder)) {
            return false;
        }

        var blockStateIds = WorldRenderingSettings.INSTANCE.getBlockStateIds();
        if (blockStateIds == null) {
            return false;
        }

        int shaderPackId = blockStateIds.getOrDefault(blockState, -1);
        int lightEmission = blockState.method_26213();
        builder.beginBlock(
                shaderPackId,
                (byte) 0,
                (byte) lightEmission,
                blockPos.method_10263(),
                blockPos.method_10264(),
                blockPos.method_10260()
        );

        if (BRIDGE_LOGGED.add(renderPath)) {
            Photonics.LOGGER.info(
                    "Photonics v20 Iris material bridge active: path={}, block={}, shaderPackId={}, emission={}",
                    renderPath,
                    class_7923.field_41175.method_10221(blockState.method_26204()),
                    shaderPackId,
                    lightEmission
            );
        }

        if (lightEmission > 0 && EMISSIVE_LOGGED.add(renderPath)) {
            Photonics.LOGGER.info(
                    "Photonics v20 emissive material captured: path={}, block={}, shaderPackId={}, emission={}",
                    renderPath,
                    class_7923.field_41175.method_10221(blockState.method_26204()),
                    shaderPackId,
                    lightEmission
            );
        }

        return true;
    }

    public static void end(class_4588 consumer, boolean active) {
        if (active && consumer instanceof BlockSensitiveBufferBuilder builder) {
            builder.endBlock();
        }
    }
}
