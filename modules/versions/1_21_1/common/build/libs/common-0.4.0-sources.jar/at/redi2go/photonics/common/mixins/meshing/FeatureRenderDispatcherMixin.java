package at.redi2go.photonics.common.mixins.meshing;

import at.redi2go.photonics.common.meshing.impl.FeatureRendererExt;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_11684;
import net.minecraft.class_11685;
import net.minecraft.class_11689;
import net.minecraft.class_11690;
import net.minecraft.class_11691;
import net.minecraft.class_11697;
import net.minecraft.class_11788;
import net.minecraft.class_11977;
import net.minecraft.class_327;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_11684.class)
public abstract class FeatureRenderDispatcherMixin implements FeatureRendererExt {
    @Unique
    private boolean renderShadows = true;
    @Unique
    private boolean renderFlames = true;
    @Unique
    private boolean renderNametags = true;
    @Unique
    private boolean renderText = true;
    @Unique
    private boolean renderParticles = true;

    @Override
    public void setRenderShadows(boolean enabled) {
        renderShadows = enabled;
    }

    @WrapOperation(
            method = "renderAllFeatures",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/feature/ShadowFeatureRenderer;render(Lnet/minecraft/client/renderer/SubmitNodeCollection;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;)V"
            )
    )
    private void renderShadows(
            class_11690 instance,
            class_11788 submitNodeCollection,
            class_4597.class_4598 bufferSource,
            Operation<Void> original
    ) {
        if (!renderShadows) return;

        original.call(instance, submitNodeCollection, bufferSource);
    }

    @Override
    public void setRenderFlames(boolean enabled) {
        renderFlames = enabled;
    }

    @WrapOperation(
            method = "renderAllFeatures",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/feature/FlameFeatureRenderer;render(Lnet/minecraft/client/renderer/SubmitNodeCollection;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;Lnet/minecraft/client/resources/model/AtlasManager;)V"
            )
    )
    private void renderFlames(
            class_11685 instance,
            class_11788 submitNodeCollection,
            class_4597.class_4598 bufferSource,
            class_11697 atlasManager,
            Operation<Void> original
    ) {
        if (!renderFlames) return;

        original.call(
                instance,
                submitNodeCollection,
                bufferSource,
                atlasManager
        );
    }

    @Override
    public void setRenderNametags(boolean enabled) {
        renderNametags = enabled;
    }

    @WrapOperation(
            method = "renderAllFeatures",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/feature/NameTagFeatureRenderer;render(Lnet/minecraft/client/renderer/SubmitNodeCollection;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;Lnet/minecraft/client/gui/Font;)V"
            )
    )
    private void renderNameTags(
            class_11689 instance,
            class_11788 submitNodeCollection,
            class_4597.class_4598 bufferSource,
            class_327 font,
            Operation<Void> original
    ) {
        if (!renderNametags) return;

        original.call(
                instance,
                submitNodeCollection,
                bufferSource,
                font
        );
    }

    @Override
    public void setRenderText(boolean enabled) {
        renderText = false;
    }

    @WrapOperation(
            method = "renderAllFeatures",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/feature/TextFeatureRenderer;render(Lnet/minecraft/client/renderer/SubmitNodeCollection;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;)V"
            )
    )
    private void renderText(
            class_11691 instance,
            class_11788 submitNodeCollection,
            class_4597.class_4598 bufferSource,
            Operation<Void> original
    ) {
        if (!renderText) return;

        original.call(
                instance,
                submitNodeCollection,
                bufferSource
        );
    }

    @Override
    public void setRenderParticles(boolean enabled) {
        renderParticles = enabled;
    }

    @WrapOperation(
            method = "renderAllFeatures",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/feature/ParticleFeatureRenderer;render(Lnet/minecraft/client/renderer/SubmitNodeCollection;)V"
            )
    )
    private void renderParticles(
            class_11977 instance,
            class_11788 submitNodeCollection,
            Operation<Void> original
    ) {
        if (!renderParticles) return;

        original.call(instance, submitNodeCollection);
    }
}
