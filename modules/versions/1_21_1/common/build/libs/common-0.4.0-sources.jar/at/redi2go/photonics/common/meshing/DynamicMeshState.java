package at.redi2go.photonics.common.meshing;

import java.util.List;
import net.minecraft.class_10889;
import net.minecraft.class_3610;

public record DynamicMeshState(
        int blockId,
        class_3610 fluidState,
        List<class_10889> blockModel
) implements McMeshState {
    @Override
    public boolean shouldCache() {
        return false;
    }

    @Override
    public void prepareCacheUse() {

    }
}
