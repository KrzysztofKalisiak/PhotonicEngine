package at.redi2go.photonics.impl.mixins.mc.nbt;

import at.redi2go.photonics.api.mc.nbt.ICompoundTag;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2487.class)
public abstract class CompoundTagMixin implements ICompoundTag{
    @Shadow
    public abstract boolean isEmpty();

    @Override
    public boolean ph$isEmpty() {
        return isEmpty();
    }
}
