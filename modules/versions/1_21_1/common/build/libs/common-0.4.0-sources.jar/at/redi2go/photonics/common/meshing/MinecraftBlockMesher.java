package at.redi2go.photonics.common.meshing;

import at.redi2go.photonics.api.mc.Id;
import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.IBlockAndTintGetter;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.common.iris.IrisUtil;
import at.redi2go.photonics.core.Photonics;
import at.redi2go.photonics.core.rendering.world.bakery.BlockBuilder;
import at.redi2go.photonics.core.rendering.world.bakery.BlockMesher;
import org.joml.Vector3i;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_1059;
import net.minecraft.class_1920;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_6862;
import net.minecraft.class_777;
import net.minecraft.class_7924;

public class MinecraftBlockMesher implements BlockMesher<McMeshState> {
    private static final Id BLOCK_ATLAS = (Id) (Object) class_1059.field_5275;
    private static final class_2350[] DIRECTIONS = class_2350.values();
    private static final class_6862<class_2248> NON_OCCLUDING_VOXELS = class_6862.method_40092(
            class_7924.field_41254,
            class_2960.method_60655("photonics", "non_occluding_voxels")
    );
    private static final class_6862<class_2248> THIN_CUTOUT_VOXELS = class_6862.method_40092(
            class_7924.field_41254,
            class_2960.method_60655("photonics", "thin_cutout_voxels")
    );
    private static final class_6862<class_2248> TALL_THIN_CUTOUT_VOXELS = class_6862.method_40092(
            class_7924.field_41254,
            class_2960.method_60655("photonics", "tall_thin_cutout_voxels")
    );
    private static final int UNKNOWN_BLOCK_ID_PAYLOAD = Integer.MAX_VALUE;
    private static final int THIN_CUTOUT_BLOCK_ID_FLAG = Integer.MIN_VALUE;
    private static final int THIN_CUTOUT_ALPHA = 96;
    private static final int TALL_THIN_CUTOUT_ALPHA = 54;
    private static final AtomicBoolean INVALID_BLOCK_ID_LOGGED = new AtomicBoolean();

    private final ThreadLocal<class_5819> random = ThreadLocal.withInitial(class_5819::method_43047);

    @Override
    public McMeshState extractMeshState(
            Vector3i blockChunkOffset,
            IBlockPos pos,
            IBlockState blockState,
            IBlockAndTintGetter blockAndTintGetter
    ) {
        class_2680 mcState = (class_2680) blockState;
        if (mcState.method_26164(NON_OCCLUDING_VOXELS)) return McMeshState.EMPTY;
        if (mcState.method_26217() != class_2464.field_11458) return McMeshState.EMPTY;

        class_2338 mcPos = (class_2338) pos;
        int thinCutoutAlpha = mcState.method_26164(TALL_THIN_CUTOUT_VOXELS)
                ? TALL_THIN_CUTOUT_ALPHA
                : mcState.method_26164(THIN_CUTOUT_VOXELS) ? THIN_CUTOUT_ALPHA : 0;
        class_1920 level = (class_1920) blockAndTintGetter;
        var modelOffset = mcState.method_26226(level, mcPos);
        var model = class_310.method_1551().method_1541().method_3349(mcState);
        var randomSource = random.get();
        var quads = new ArrayList<class_777>();

        randomSource.method_43052(mcState.method_26190(mcPos));
        quads.addAll(model.method_4707(mcState, null, randomSource));

        for (class_2350 direction : DIRECTIONS) {
            randomSource.method_43052(mcState.method_26190(mcPos));
            quads.addAll(model.method_4707(mcState, direction, randomSource));
        }

        if (quads.isEmpty()) return McMeshState.EMPTY;

        boolean positionTinted = quads.stream().anyMatch(class_777::method_3360);
        int blockId = packBlockId(IrisUtil.getBlockId(mcState), thinCutoutAlpha != 0);

        return new McMeshState(
                blockId,
                thinCutoutAlpha,
                positionTinted,
                (float) modelOffset.field_1352,
                (float) modelOffset.field_1351,
                (float) modelOffset.field_1350,
                List.copyOf(quads)
        );
    }

    @Override
    public void meshBlock(
            McMeshState meshState,
            Vector3i blockChunkOffset,
            IBlockPos pos,
            IBlockState blockState,
            IBlockAndTintGetter blockAndTintGetter,
            BlockBuilder blockBuilder
    ) {
        if (meshState == McMeshState.EMPTY) return;

        class_2680 mcState = (class_2680) blockState;
        class_2338 mcPos = (class_2338) pos;
        class_1920 level = (class_1920) blockAndTintGetter;

        // BakedQuad positions are block-local; WorldCompiler applies the block position later.
        blockBuilder
                .useAtlas(BLOCK_ATLAS)
                .useBlockId(meshState.blockId())
                .useOffset(meshState.offsetX(), meshState.offsetY(), meshState.offsetZ());

        for (class_777 quad : meshState.quads()) {
            int tint = getTint(
                    mcState,
                    level,
                    mcPos,
                    quad,
                    meshState.thinCutoutAlpha()
            );
            int[] vertices = quad.method_3357();
            for (int vertex = 0; vertex < 4; vertex++) {
                int offset = vertex * 8;
                blockBuilder
                        .addVertex(
                                Float.intBitsToFloat(vertices[offset]),
                                Float.intBitsToFloat(vertices[offset + 1]),
                                Float.intBitsToFloat(vertices[offset + 2])
                        )
                        .setTint(tint)
                        .setUv(
                                Float.intBitsToFloat(vertices[offset + 4]),
                                Float.intBitsToFloat(vertices[offset + 5])
                        );
            }
        }
    }

    private static int getTint(
            class_2680 state,
            class_1920 level,
            class_2338 pos,
            class_777 quad,
            int thinCutoutAlpha
    ) {
        int tint = 0xFFFFFFFF;
        if (quad.method_3360()) {
            tint = class_310.method_1551().method_1505().method_1697(
                    state,
                    level,
                    pos,
                    quad.method_3359()
            );
            tint = 0xFF000000 | tint;
        }

        return thinCutoutAlpha != 0
                ? (thinCutoutAlpha << 24) | (tint & 0x00FFFFFF)
                : tint;
    }

    private static int packBlockId(int blockId, boolean thinCutout) {
        int payload;
        if (blockId == -1) {
            payload = UNKNOWN_BLOCK_ID_PAYLOAD;
        } else if (blockId >= 0 && blockId < UNKNOWN_BLOCK_ID_PAYLOAD) {
            payload = blockId;
        } else {
            payload = UNKNOWN_BLOCK_ID_PAYLOAD;
            if (INVALID_BLOCK_ID_LOGGED.compareAndSet(false, true))
                Photonics.LOGGER.warn(
                        "Photonics cannot pack Iris block id {}; using the unknown-id sentinel",
                        blockId
                );
        }

        return thinCutout ? payload | THIN_CUTOUT_BLOCK_ID_FLAG : payload;
    }
}
