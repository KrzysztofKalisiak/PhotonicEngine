package at.redi2go.photonics.common.meshing;

import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.IBlockAndTintGetter;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.core.rendering.world.bakery.BlockBuilder;
import at.redi2go.photonics.core.rendering.world.bakery.BlockMesher;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_778;
import org.joml.Vector3i;

public class MinecraftBlockMesher implements BlockMesher<McMeshState> {
    private static final ThreadLocal<McBlockRenderer> RENDERERS = ThreadLocal.withInitial(McBlockRenderer::new);

    @Override
    public void setup() {
        class_778.method_20544();
    }

    @Override
    public void teardown() {
        class_778.method_20545();
    }

    @Override
    public McMeshState extractMeshState(
            Vector3i blockChunkOffset,
            IBlockPos pos,
            IBlockState blockState,
            IBlockAndTintGetter blockAndTintGetter
    ) {
        return RENDERERS.get().extractMeshState(
                blockChunkOffset,
                (class_2338) pos,
                (class_2680) blockState,
                (class_1920) blockAndTintGetter
        );
    }

    @Override
    public void meshBlock(
            McMeshState meshState,
            Vector3i blockChunkOffset,
            IBlockPos pos,
            IBlockState blockState,
            IBlockAndTintGetter blockAndTintGetter,
            BlockBuilder blockBuilder
    ) {
        RENDERERS.get().meshBlock(
                meshState,
                blockChunkOffset,
                (class_2338) pos,
                (class_2680) blockState,
                (class_1920) blockAndTintGetter,
                blockBuilder
        );
    }
}
