package at.redi2go.photonics.impl.mixins.mc.blaze3d.opengl.buffer;

import net.minecraft.class_10859;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10859.class)
public interface GlBufferAccessor {
    @Accessor
    int getHandle();
}
