package at.redi2go.photonics.common.meshing;

import at.redi2go.photonics.core.rendering.world.bakery.BlockMeshState;
import java.util.List;
import net.minecraft.class_10889;
import net.minecraft.class_3610;

public interface McMeshState extends BlockMeshState {
    int blockId();

    class_3610 fluidState();

    List<class_10889> blockModel();
}
