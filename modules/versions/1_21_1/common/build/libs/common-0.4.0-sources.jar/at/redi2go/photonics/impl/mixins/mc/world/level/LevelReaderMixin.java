package at.redi2go.photonics.impl.mixins.mc.world.level;

import at.redi2go.photonics.api.mc.core.IRegistryAccess;
import at.redi2go.photonics.api.mc.world.level.ILevelReader;
import net.minecraft.class_4538;
import net.minecraft.class_5455;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_4538.class)
public interface LevelReaderMixin extends ILevelReader {
    @Shadow
    class_5455 registryAccess();

    @Override
    default IRegistryAccess ph$registryAccess() {
        return (IRegistryAccess) registryAccess();
    }
}
