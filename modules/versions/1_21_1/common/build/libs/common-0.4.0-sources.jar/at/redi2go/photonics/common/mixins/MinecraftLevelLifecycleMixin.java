package at.redi2go.photonics.common.mixins;

import at.redi2go.photonics.common.iris.IrisUtil;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftLevelLifecycleMixin {
    @Inject(method = "clearClientLevel", at = @At("HEAD"))
    private void closePhotonicsForLevel(class_437 screen, CallbackInfo ci) {
        IrisUtil.getPipelineManager().closePhotonics("client-level-cleared");
    }
}
