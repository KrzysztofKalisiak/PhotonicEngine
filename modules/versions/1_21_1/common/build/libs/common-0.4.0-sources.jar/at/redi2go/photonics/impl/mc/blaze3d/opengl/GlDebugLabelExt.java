package at.redi2go.photonics.impl.mc.blaze3d.opengl;

import at.redi2go.photonics.impl.mc.blaze3d.opengl.textures.GlTexture2D;
import at.redi2go.photonics.impl.mc.blaze3d.opengl.textures.IGlTexture;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10865;

public interface GlDebugLabelExt {
    void applyLabel(IGlTexture texture2D);

    static GlDebugLabelExt getInstance() {
        return (GlDebugLabelExt) ((class_10865) RenderSystem.getDevice()).method_68377();
    }
}
