package at.redi2go.photonics.impl.mixins.mc.blaze3d.opengl.systems;

import net.minecraft.class_10874;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_10874.class)
public interface DirectStateAccessor {
    @Invoker
    void invokeBindFrameBufferTextures(int i, int j, int k, int l, int m);
}
