package at.redi2go.photonics.common.iris.pipeline.framebuffer;

import net.minecraft.class_310;
import org.joml.RoundingMode;
import org.joml.Vector2i;
import org.joml.Vector2ic;

public interface FramebufferSize {
    Vector2ic get();

    record Fixed(int width, int height) implements FramebufferSize {
        @Override
        public Vector2ic get() {
            return new Vector2i(width, height);
        }
    }

    record Relative(float width, float height) implements FramebufferSize {
        private static final Vector2i ONE = new Vector2i(1);

        public Relative {
            if (width < 0f || width > 1f) throw new IllegalArgumentException("width was " + width + "; expected 0..1");
            if (height < 0f || height > 1f) throw new IllegalArgumentException("height was " + width + "; expected 0..1");
        }

        @Override
        public Vector2ic get() {
            float newWidth = class_310.method_1551().method_22683().method_4489() * width;
            float newHeight = class_310.method_1551().method_22683().method_4506() * height;

            return new Vector2i(
                    newWidth,
                    newHeight,
                    RoundingMode.TRUNCATE
            ).max(ONE);
        }
    }
}
