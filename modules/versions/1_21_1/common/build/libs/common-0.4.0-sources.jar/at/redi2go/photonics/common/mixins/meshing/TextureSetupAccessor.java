package at.redi2go.photonics.common.mixins.meshing;

import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(targets = { "net.minecraft.client.renderer.rendertype.RenderSetup$TextureBinding" })
public interface TextureSetupAccessor {
    @Accessor
    class_2960 getLocation();
}
