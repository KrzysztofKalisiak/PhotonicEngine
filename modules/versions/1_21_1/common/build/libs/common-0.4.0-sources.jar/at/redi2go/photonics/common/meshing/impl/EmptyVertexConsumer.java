package at.redi2go.photonics.common.meshing.impl;

import net.minecraft.class_4588;

public class EmptyVertexConsumer implements class_4588 {
    public static final class_4588 INSTANCE = new EmptyVertexConsumer();

    private EmptyVertexConsumer() {

    }

    @Override
    public class_4588 method_22912(float f, float g, float h) {
        return this;
    }

    @Override
    public class_4588 method_1336(int i, int j, int k, int l) {
        return this;
    }

    @Override
    public class_4588 method_39415(int i) {
        return this;
    }

    @Override
    public class_4588 method_22913(float f, float g) {
        return this;
    }

    @Override
    public class_4588 method_60796(int i, int j) {
        return this;
    }

    @Override
    public class_4588 method_22921(int i, int j) {
        return this;
    }

    @Override
    public class_4588 method_22914(float f, float g, float h) {
        return this;
    }

    @Override
    public class_4588 method_75298(float f) {
        return this;
    }
}
