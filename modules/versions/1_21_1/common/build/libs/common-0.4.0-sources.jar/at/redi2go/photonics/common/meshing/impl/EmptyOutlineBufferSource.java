package at.redi2go.photonics.common.meshing.impl;

import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4618;
import org.jspecify.annotations.NonNull;

public class EmptyOutlineBufferSource extends class_4618 {
    public static final EmptyOutlineBufferSource INSTANCE = new EmptyOutlineBufferSource();

    private EmptyOutlineBufferSource() {
    }

    @Override
    public class_4588 method_73477(@NonNull class_1921 renderType) {
        return EmptyVertexConsumer.INSTANCE;
    }

    @Override
    public void method_23286(int i) {

    }

    @Override
    public void method_23285() {

    }
}
