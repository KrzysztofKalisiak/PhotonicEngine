package at.redi2go.photonics.core.rendering;

import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.api.mc.world.level.ILevel;
import at.redi2go.photonics.api.mc.world.level.chunk.IChunkSection;
import at.redi2go.photonics.core.rendering.world.block.VoxelNormal;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.Nullable;
import org.joml.RoundingMode;
import org.joml.Vector3i;

import java.util.Arrays;

public class SectionCopy implements PrioritizedTask, IChunkSection {
    private final Vector3i pos;
    private final IChunkSection copy;
    private final long priority;
    private final boolean playerChanged;

    public SectionCopy(
            Vector3i pos,
            IChunkSection section,
            long priority
    ) {
        this(pos, section, priority, false);
    }

    public SectionCopy(
            Vector3i pos,
            IChunkSection section,
            long priority,
            boolean playerChanged
    ) {
        this.pos = pos;
        this.copy = section.ph$createCopy();
        this.priority = priority;
        this.playerChanged = playerChanged;
    }

    @Override
    public long priority() {
        return this.priority;
    }

    public Vector3i pos() {
        return pos;
    }

    public Vector3i blockPos() {
        return pos.mul(16, new Vector3i());
    }

    public boolean playerChanged() {
        return playerChanged;
    }

    @Override
    public IBlockState ph$getBlockState(int x, int y, int z) {
        return copy.ph$getBlockState(x, y, z);
    }

    @Override
    public boolean ph$hasOnlyAir() {
        return false;
    }

    @Override
    public IChunkSection ph$createCopy() {
        return this;
    }

    public void forEachBlock(TriConsumer<Vector3i, IBlockPos, IBlockState> blockConsumer) {
        Vector3i chunkOffset = new Vector3i();
        Vector3i sectionBlockPos = blockPos();

        for (int px = 0; px < 16; px++) {
            for (int py = 0; py < 16; py++) {
                for (int pz = 0; pz < 16; pz++) {
                    IBlockPos blockPos = IBlockPos.of(
                            sectionBlockPos.x + px,
                            sectionBlockPos.y + py,
                            sectionBlockPos.z + pz
                    );

                    chunkOffset.set(px, py, pz);
                    blockConsumer.accept(chunkOffset, blockPos, ph$getBlockState(px, py, pz));
                }
            }
        }
    }

    public SectionHashes computeSectionHashes(@Nullable ILevel level) {
        return computeSectionHashes(level, false);
    }

    public SectionHashes computeSectionHashes(
            @Nullable ILevel level,
            boolean captureSceneBlockHashes
    ) {
        final long[] sectionHash = {0};
        final long[] sceneHash = {0};
        // The traversal is in block-index order, so this remains sorted and
        // can be retained sparsely after the hash pass.
        final long[] nonAirEntries = new long[16 * 16 * 16];
        final int[] nonAirCount = {0};
        final int[] sceneBlockHashes = captureSceneBlockHashes ? new int[16 * 16 * 16] : null;
        final String[] sceneBlockDescriptions = captureSceneBlockHashes ? new String[16 * 16 * 16] : null;

        forEachBlock((blockOffset, blockPos, block) -> {
            // BlockState does not define value equality on 1.21.1, so its
            // identity hash changes when a copied section is rebuilt. The
            // registry-backed stable state hash is sufficient for both
            // deduplication and scene-content tracking.
            int blockHash = block.ph$stableHash();
            int skylight = level == null ? 0 : compileSkylight(level, blockPos);
            int blockIndex = (blockOffset.x() * 16 + blockOffset.y()) * 16 + blockOffset.z();

            if (!block.ph$isAir()) {
                nonAirEntries[nonAirCount[0]++] =
                        ((long) blockIndex << 32) | Integer.toUnsignedLong(blockHash);
            }

            long packedBlock = (((long) skylight) << 32) | Integer.toUnsignedLong(blockHash);
            sectionHash[0] = sectionHash[0] * 31 + packedBlock;
            sceneHash[0] = sceneHash[0] * 31 + Integer.toUnsignedLong(blockHash);

            if (sceneBlockHashes != null) {
                sceneBlockHashes[blockIndex] = blockHash;
                sceneBlockDescriptions[blockIndex] = block.toString();
            }
        });

        return new SectionHashes(
                sectionHash[0],
                sceneHash[0],
                new SceneOccupancy(
                        Arrays.copyOf(nonAirEntries, nonAirCount[0]),
                        nonAirCount[0]
                ),
                sceneBlockHashes,
                sceneBlockDescriptions
        );
    }

    public long computeSectionHash(@Nullable ILevel level) {
        return computeSectionHashes(level).sectionHash();
    }

    public static Vector3i getSectionCoord(IBlockPos blockPos) {
        return new Vector3i(
                blockPos.ph$x() >> 4,
                blockPos.ph$y() >> 4,
                blockPos.ph$z() >> 4
        );
    }

    public static int compileSkylight(ILevel level, IBlockPos pos) {
        int brightness = level.ph$getSkylightValue(pos);

        int result = 0;
        for (int i = 5; i >= 0; i--) {
            var normal = new Vector3i(VoxelNormal.getNormal(i), RoundingMode.TRUNCATE);
            int skylight = level.ph$getSkylightValue(pos.ph$offset(normal));

            result <<= 4;
            result |= Math.max(skylight, brightness);
        }

        return result;
    }

    public record SectionHashes(
            long sectionHash,
            long sceneHash,
            SceneOccupancy sceneOccupancy,
            @Nullable int[] sceneBlockHashes,
            @Nullable String[] sceneBlockDescriptions
    ) {}

    /** Sparse geometry occupancy used to distinguish streaming population from edits. */
    public record SceneOccupancy(
            long[] nonAirEntries,
            int nonAirCount
    ) {}
}
