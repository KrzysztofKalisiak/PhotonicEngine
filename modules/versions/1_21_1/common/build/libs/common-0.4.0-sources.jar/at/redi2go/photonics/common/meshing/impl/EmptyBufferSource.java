package at.redi2go.photonics.common.meshing.impl;

import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.jspecify.annotations.NonNull;

public class EmptyBufferSource extends class_4597.class_4598 {
    public static final EmptyBufferSource INSTANCE = new EmptyBufferSource();

    private EmptyBufferSource() {
        super(null, null);
    }

    @Override
    public @NonNull class_4588 method_73477(@NonNull class_1921 renderType) {
        return EmptyVertexConsumer.INSTANCE;
    }

    @Override
    public void method_37104() {

    }

    @Override
    public void method_22993() {

    }

    @Override
    public void method_22994(@NonNull class_1921 renderType) {

    }
}
