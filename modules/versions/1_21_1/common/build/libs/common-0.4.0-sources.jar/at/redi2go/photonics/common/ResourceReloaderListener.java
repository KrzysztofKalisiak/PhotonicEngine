package at.redi2go.photonics.common;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_310;
import net.minecraft.class_3304;
import net.minecraft.class_4013;

public class ResourceReloaderListener {
    private static final Set<Runnable> DEPENDANTS = ConcurrentHashMap.newKeySet();

    static {
        ((class_3304) class_310.method_1551().method_1478())
                .method_14477((class_4013) resourceManager -> {
                    for (var runnable : DEPENDANTS)
                        runnable.run();
                });
    }

    public static void add(Runnable runnable) {
        DEPENDANTS.add(runnable);
    }

    public static void remove(Runnable runnable) {
        DEPENDANTS.remove(runnable);
    }
}
