package at.redi2go.photonics.common.mixins.rendering.world.bakery;

import at.redi2go.photonics.core.rendering.world.bakery.BlockBuilder;
import at.redi2go.photonics.core.rendering.world.block.VoxelColor;
import net.minecraft.class_4588;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(BlockBuilder.class)
public interface VertexBuilderMixin extends class_4588 {
    @Shadow
    BlockBuilder shadow$addVertex(float x, float y, float z);

    @Override
    default @NotNull class_4588 method_22912(float x, float y, float z) {
        return (class_4588) shadow$addVertex(x, y, z);
    }

    @Shadow
    BlockBuilder shadow$setTint(int color);

    @Override
    default @NotNull class_4588 method_39415(int argb) {
        return (class_4588) shadow$setTint(argb);
    }

    @Override
    default @NotNull class_4588 method_1336(int r, int g, int b, int a) {
        return (class_4588) shadow$setTint(VoxelColor.from(r, g, b, a));
    }

    @Shadow
    BlockBuilder shadow$setUv(float u, float v);

    @Override
    default @NotNull class_4588 method_22913(float u, float v) {
        return (class_4588) shadow$setUv(u, v);
    }

    @Override
    default @NotNull class_4588 method_60796(int i, int j) {
        return this;
    }

    @Override
    default class_4588 method_22921(int i, int j) {
        return this;
    }

    @Override
    default class_4588 method_22914(float f, float g, float h) {
        return this;
    }
}
