package at.redi2go.photonics.common;

import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.core.rendering.lights.HandheldItem;
import at.redi2go.photonics.core.rendering.lights.HandheldItemSupplier;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public class HandheldLightSupplierImpl implements HandheldItemSupplier {
    private static final Map<class_1792, class_2680> ITEM_TO_BLOCK = Map.of(
            class_1802.field_8187,
            class_2246.field_10164.method_9564()
    );

    @Override
    public boolean isLeftHanded() {
        return class_310.method_1551().field_1690.method_42552().method_41753() == class_1306.field_6182;
    }


    private Optional<HandheldItem> getHandheldItem(class_1304 slot) {
        return Optional.ofNullable(class_310.method_1551().field_1724)
                .map(player -> player.method_6118(slot))
                .filter(stack -> !stack.method_7960())
                .flatMap(stack -> {
                    var mapped = ITEM_TO_BLOCK.get(stack.method_7909());
                    if (mapped != null) return Optional.of(new BlockItem(mapped, false));

                    return class_7923.field_41178.method_29113(stack.method_7909())
                            .flatMap(e -> class_7923.field_41175.method_17966(e.method_29177()))
                            .map(block -> new BlockItem(block.method_9564(), stack.method_7942()));
                });
    }

    @Override
    public Optional<HandheldItem> getMainHand() {
        return getHandheldItem(class_1304.field_6173);
    }

    @Override
    public Optional<HandheldItem> getOffHand() {
        return getHandheldItem(class_1304.field_6171);
    }

    private record BlockItem(class_2680 blockState, boolean isEnchanted) implements HandheldItem {
        @Override
        public IBlockState getBlockState() {
            return (IBlockState) blockState;
        }
    }
}
