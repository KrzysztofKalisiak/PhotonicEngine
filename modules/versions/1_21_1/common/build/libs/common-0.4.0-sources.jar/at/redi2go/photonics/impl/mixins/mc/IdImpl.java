package at.redi2go.photonics.impl.mixins.mc;

import at.redi2go.photonics.api.mc.Id;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value = Id.class)
public interface IdImpl {
    @Overwrite
    static Id fromNamespaceAndPath(String namespace, String path) {
        return (Id) (Object) class_2960.method_60655(namespace, path);
    }

    @Overwrite
    static Id parse(String string) {
        return (Id) (Object) class_2960.method_60654(string);
    }

    @Overwrite
    static Id withDefaultNamespace(String path) {
        return (Id) (Object) class_2960.method_60656(path);
    }
}
