package at.redi2go.photonics.common.meshing;

import java.util.List;
import net.minecraft.class_10889;
import net.minecraft.class_3610;
import net.minecraft.class_3612;

public class EmptyMeshState implements McMeshState {
    public static final EmptyMeshState INSTANCE = new EmptyMeshState();

    private EmptyMeshState() {

    }

    @Override
    public int blockId() {
        return -1;
    }

    @Override
    public class_3610 fluidState() {
        return class_3612.field_15906.method_15785();
    }

    @Override
    public List<class_10889> blockModel() {
        return List.of();
    }

    @Override
    public boolean shouldCache() {
        return true;
    }

    @Override
    public void prepareCacheUse() {

    }
}
