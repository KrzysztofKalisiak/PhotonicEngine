package at.redi2go.photonics.impl.mixins.mc.world.level;

import at.redi2go.photonics.api.mc.world.level.chunk.IChunkAccess;
import at.redi2go.photonics.api.mc.world.level.chunk.IChunkSection;
import net.minecraft.class_2791;
import net.minecraft.class_2826;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2791.class)
public abstract class ChunkAccessMixin implements IChunkAccess {
    @Shadow
    public abstract class_2826[] getSections();

    @Override
    public IChunkSection[] ph$sections() {
        return (IChunkSection[]) getSections();
    }
}
