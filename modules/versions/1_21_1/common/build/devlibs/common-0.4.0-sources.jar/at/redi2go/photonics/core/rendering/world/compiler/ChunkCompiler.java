package at.redi2go.photonics.core.rendering.world.compiler;

import at.redi2go.photonics.api.Disposable;
import at.redi2go.photonics.api.mc.Minecraft;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.api.mc.world.level.ILevel;
import at.redi2go.photonics.core.Photonics;
import at.redi2go.photonics.core.rendering.PrioritizedTask;
import at.redi2go.photonics.core.rendering.RenderingComponent;
import at.redi2go.photonics.core.rendering.SectionManager;
import at.redi2go.photonics.core.rendering.world.bakery.BlockMesher;
import at.redi2go.photonics.core.rendering.world.IgnoredInterruptedException;
import at.redi2go.photonics.core.rendering.world.block.BlockModel;
import at.redi2go.photonics.core.rendering.world.registry.WorldRegistry;
import at.redi2go.photonics.core.rendering.world.registry.light.WorldLight;
import at.redi2go.photonics.core.rendering.world.registry.light.WorldLightRegistry;
import org.apache.logging.log4j.util.BiConsumer;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3i;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicInteger;

public class ChunkCompiler implements Runnable, RenderingComponent {
    private static final int THREAD_COUNT = 2;

    private final Queue<Vector3i> unloadQueue;
    private final SectionManager.SectionQueue sectionQueue;
    private final SectionManager.TaskQueue<ChunkCompiler.BuildResult> builtSectionQueue;

    private final WorldRegistry worldRegistry;

    private final ConcurrentMap<Vector3i, Long> latestSection = new ConcurrentHashMap<>();
    private final ConcurrentMap<Vector3i, Long> sectionHashes = new ConcurrentHashMap<>();

    private final Thread[] threads = new Thread[THREAD_COUNT];

    public ChunkCompiler(
            SectionManager sectionManager,
            SectionManager.TaskQueue<ChunkCompiler.BuildResult> builtSectionQueue,
            WorldRegistry worldRegistry
    ) {
        this.unloadQueue = sectionManager.newUnloadQueue();
        this.sectionQueue = sectionManager.newSectionQueue(false);
        this.builtSectionQueue = builtSectionQueue;

        this.worldRegistry = worldRegistry;

        for (int i = 0; i < THREAD_COUNT; i++) {
            var thread = new Thread(this, "Photonic Chunk Compiler #" + i);
            threads[i] = thread;

            thread.setDaemon(false);
            thread.start();
        }
    }

    @Override
    public void run() {
        try {
            while (!Thread.interrupted()) {
                sectionQueue.awaitTask();
                var result = sectionQueue.take();

                if (result.isEmpty()) continue;

                var section = result.get();
                unloadChunks();

                ILevel level = Minecraft.getLevel();
                if (level == null) continue;

                if (!isLatestSection(section.pos(), section.priority())) continue;

                // Computing the hash immediately is cheaper than meshing an entire section just to discard it
                long hash = section.computeSectionHash(level);
                if (isDuplicateSection(section.pos(), hash)) continue;

                var buildResult = new BuildResult(section.pos(), section.blockPos(), hash, section.priority());

                BlockMesher.REGISTRY.setup();

                section.forEachBlock((blockChunkOffset, blockPos, block) -> {
                    if (block.ph$isAir()) return;

                    BlockMesher.REGISTRY.get(block.ph$block())
                            .ifPresent(mesher -> buildResult.submitBlockFuture(
                                    blockChunkOffset.x(),
                                    blockChunkOffset.y(),
                                    blockChunkOffset.z(),
                                    block,
                                    worldRegistry.blockModelRegistry().getBlockModel(
                                            mesher,
                                            new Vector3i(blockChunkOffset),
                                            blockPos,
                                            block,
                                            level
                                    )
                            ));
                });

                BlockMesher.REGISTRY.teardown();

                buildResult.awaitSubmission();
            }
        } catch (Throwable t) {
            if (t instanceof InterruptedException) return;
            if (IgnoredInterruptedException.shouldIgnore(t)) return;

            Photonics.LOGGER.warn("An exception was throw during chunk compilation!", t);
        }
    }

    private boolean isLatestSection(Vector3i pos, long priority) {
        return priority > latestSection.getOrDefault(pos, Long.MIN_VALUE);
    }

    private boolean setLatestSection(Vector3i pos, long priority) {
        return latestSection.compute(pos, (ignored, previous) -> {
            if (previous == null) return priority;
            if (priority > previous) return priority;

            return previous;
        }).equals(priority);
    }

    private boolean isDuplicateSection(Vector3i pos, long hash) {
        return Objects.equals(sectionHashes.get(pos), hash);
    }

    private boolean setSectionHash(Vector3i pos, long hash) {
        var previousHash = sectionHashes.put(pos, hash);
        return !Objects.equals(previousHash, hash);
    }

    private void unloadChunks() {
        while (!unloadQueue.isEmpty()) {
            var section = unloadQueue.poll();
            if (section == null) continue;

            sectionHashes.remove(section);
            latestSection.remove(section);
        }
    }

    @Override
    public void close() {
        for (var thread : threads)
            thread.interrupt();
    }

    public class BuildResult implements PrioritizedTask, Disposable {
        private final Vector3i chunkPos;
        private final Vector3i chunkBlockPos;
        private final long hash;
        private final long priority;

        private final List<BlockResult> blocks = new ArrayList<>(128);

        private final AtomicInteger pendingBlocks = new AtomicInteger();
        private final CompletableFuture<Void> future = new CompletableFuture<>();

        public BuildResult(
                Vector3i chunkPos,
                Vector3i chunkBlockPos,
                long hash,
                long priority
        ) {
            this.chunkPos = chunkPos;
            this.chunkBlockPos = chunkBlockPos;
            this.hash = hash;
            this.priority = priority;
        }

        public Vector3i chunkPos() {
            return chunkPos;
        }

        public Vector3i chunkBlockPos() {
            return chunkBlockPos;
        }

        @Override
        public long priority() {
            return priority;
        }

        private void submitBlockFuture(
                int x, int y, int z,
                IBlockState blockState,
                CompletionStage<@Nullable BlockModel> block
        ) {
            while (true) {
                int pending = pendingBlocks.get();
                if (pending == -1) throw new IllegalStateException();

                int remaining = (pending & Integer.MAX_VALUE) + 1;
                if (pendingBlocks.compareAndSet(pending, remaining | (pending & Integer.MIN_VALUE))) {
                    block.handle((result, t) -> {
                        if (!IgnoredInterruptedException.shouldIgnore(t))
                            Photonics.LOGGER.error("An error was thrown while meshing block", t);

                        try {
                            completeBlock(x, y, z, blockState, result);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        } catch (Throwable t2) {
                            Photonics.LOGGER.error("Error while setting block", t2);
                        }

                        return null;
                    });

                    return;
                }
            }
        }

        private void completeBlock(
                int x, int y, int z,
                IBlockState blockState,
                @Nullable BlockModel blockModel
                ) throws InterruptedException {
            if (blockModel != null)
                blocks.add(new BlockResult(x, y, z, blockState, blockModel));

            while (true) {
                int pending = pendingBlocks.get();
                if (pending == -1) throw new IllegalStateException();

                int remaining = (pending & Integer.MAX_VALUE) - 1;
                if (pendingBlocks.compareAndSet(pending, remaining | (pending & Integer.MIN_VALUE))) {
                    trySubmit();

                    return;
                }
            }
        }

        private void trySubmit() throws InterruptedException {
            while (true) {
                int pending = pendingBlocks.get();
                if (pending == -1 || (pending & Integer.MIN_VALUE) == 0) return;

                int remaining = pending & Integer.MAX_VALUE;
                if (remaining > 0) return;

                // This is safe because the max possible pending is 4096
                if (pendingBlocks.compareAndSet(pending, -1)) {
                    future.complete(null);

                    return;
                }
            }
        }

        private void awaitSubmission() throws InterruptedException, ExecutionException {
            while (true) {
                int pending = pendingBlocks.get();
                if ((pending & Integer.MIN_VALUE) != 0) return;

                if (pendingBlocks.compareAndSet(pending, pending | Integer.MIN_VALUE)) {
                    trySubmit();
                    break;
                }
            }


            future.get();

            if (setLatestSection(chunkPos, priority) && setSectionHash(chunkPos, hash)) {
                builtSectionQueue.offer(chunkPos, this);
            } else close();
        }

        public void forEachBlock(TriConsumer<Vector3i, IBlockState, BlockModel> blockConsumer) {
            for (var block : blocks)
                blockConsumer.accept(block, block.blockState, block.model);
        }

        @Override
        public void close() {
            for (var block : blocks)
                block.model.close();
        }
    }

    private static class BlockResult extends Vector3i {
        public final BlockModel model;
        public final IBlockState blockState;

        public BlockResult(
                int x, int y, int z,
                IBlockState blockState,
                BlockModel model
        ) {
            super(x, y, z);

            this.blockState = blockState;
            this.model = model;
        }
    }
}
