package at.redi2go.photonics.impl.mixins.mc.world.level.block.state;

import at.redi2go.photonics.api.mc.IProperty;
import at.redi2go.photonics.api.mc.world.level.block.state.IStateDefinition;
import net.minecraft.class_2689;
import net.minecraft.class_2769;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2689.class)
public abstract class StateDefinitionMixin implements IStateDefinition {
    @Shadow
    public abstract class_2769<?> getProperty(String string);

    @Override
    public @Nullable IProperty<?> ph$getProperty(String string) {
        return (IProperty<?>) getProperty(string);
    }
}
