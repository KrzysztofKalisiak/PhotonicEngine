package at.redi2go.photonics.impl.mixins.mc.world.level;

import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.api.mc.world.level.chunk.IChunkSection;
import net.minecraft.class_1959;
import net.minecraft.class_2680;
import net.minecraft.class_2826;
import net.minecraft.class_2841;
import net.minecraft.class_6880;
import net.minecraft.class_7522;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2826.class)
public abstract class LevelChunkSectionMixin implements IChunkSection {
    @Shadow
    public abstract class_2680 getBlockState(int x, int y, int z);

    @Shadow
    public abstract boolean hasOnlyAir();

    @Shadow
    public abstract class_2841<class_2680> getStates();

    @Shadow
    public abstract class_7522<class_6880<class_1959>> getBiomes();

    @Override
    public IBlockState ph$getBlockState(int x, int y, int z) {
        return (IBlockState) getBlockState(x, y, z);
    }

    @Override
    public boolean ph$hasOnlyAir() {
        return hasOnlyAir();
    }

    @Override
    public IChunkSection ph$createCopy() {
        return (IChunkSection) new class_2826(getStates().method_39957(), getBiomes().method_44350());
    }
}
