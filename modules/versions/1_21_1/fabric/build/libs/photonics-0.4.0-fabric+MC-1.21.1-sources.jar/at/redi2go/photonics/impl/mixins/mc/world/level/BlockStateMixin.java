package at.redi2go.photonics.impl.mixins.mc.world.level;

import at.redi2go.photonics.api.mc.IProperty;
import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.IBlock;
import at.redi2go.photonics.api.mc.world.level.IBlockGetter;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import com.mojang.serialization.MapCodec;
import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2680.class)
@SuppressWarnings("unchecked")
public abstract class BlockStateMixin extends class_4970.class_4971 implements IBlockState {
    @Override
    public IBlock ph$block() {
        return (IBlock) method_26204();
    }

    @Override
    public boolean ph$isAir() {
        return method_26215();
    }

    @Override
    public boolean ph$isSuffocating(IBlockGetter blockGetter, IBlockPos blockPos) {
        return method_26228((class_1922) blockGetter, (class_2338) blockPos);
    }

    @Override
    public boolean ph$isCollisionShapeFullBlock(IBlockGetter blockGetter, IBlockPos blockPos) {
        return method_26234((class_1922) blockGetter, (class_2338) blockPos);
    }

    @Override
    public boolean ph$hasProperty(IProperty<?> property) {
        return method_28498((class_2769<?>) property);
    }

    @Override
    public <T extends Comparable<T>> T ph$getValue(IProperty<T> property) {
        return method_11654((class_2769<T>) property);
    }

    private BlockStateMixin(
            class_2248 block,
            Reference2ObjectArrayMap<class_2769<?>, Comparable<?>> reference2ObjectArrayMap,
            MapCodec<class_2680> mapCodec
    ) {
        super(block, reference2ObjectArrayMap, mapCodec);
    }
}
