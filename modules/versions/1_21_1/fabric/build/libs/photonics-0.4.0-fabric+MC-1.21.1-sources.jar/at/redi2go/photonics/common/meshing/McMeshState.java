package at.redi2go.photonics.common.meshing;

import at.redi2go.photonics.core.rendering.world.bakery.BlockMeshState;
import java.util.List;
import net.minecraft.class_777;

public record McMeshState(
        int blockId,
        int thinCutoutAlpha,
        boolean positionTinted,
        float offsetX,
        float offsetY,
        float offsetZ,
        List<class_777> quads
) implements BlockMeshState {
    public static final McMeshState EMPTY = new McMeshState(-1, 0, false, 0.0f, 0.0f, 0.0f, List.of());

    @Override
    public boolean shouldCache() {
        return this != EMPTY && !positionTinted;
    }

    @Override
    public void prepareCacheUse() {
    }
}
