package at.redi2go.photonics.common.meshing;

import at.redi2go.photonics.core.rendering.world.bakery.BlockMeshState;
import java.util.List;
import net.minecraft.class_777;

public record McMeshState(int blockId, List<class_777> quads) implements BlockMeshState {
    public static final McMeshState EMPTY = new McMeshState(-1, List.of());

    @Override
    public boolean shouldCache() {
        return this != EMPTY;
    }

    @Override
    public void prepareCacheUse() {
    }
}
