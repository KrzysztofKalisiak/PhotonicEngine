package at.redi2go.photonics.impl.mixins.mc.commands.arguments.blocks;

import at.redi2go.photonics.api.mc.IProperty;
import at.redi2go.photonics.api.mc.commands.arguments.blocks.IBlockStateParser;
import at.redi2go.photonics.api.mc.nbt.ICompoundTag;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.class_2259;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2769;

@Mixin(class_2259.class_7211.class)
public abstract class BlockStateParser$BlockResultMixin implements IBlockStateParser.BlockResult{
    @Shadow
    public abstract class_2680 blockState();

    @Shadow
    public abstract Map<class_2769<?>, Comparable<?>> properties();

    @Shadow
    public abstract @Nullable class_2487 nbt();

    @Override
    public IBlockState ph$blockState() {
        return (IBlockState) blockState();
    }

    @Override
    public Map<IProperty<?>, Comparable<?>> ph$properties() {
        return (Map) properties();
    }

    @Override
    public ICompoundTag ph$nbt() {
        return (ICompoundTag) (Object) nbt();
    }
}
