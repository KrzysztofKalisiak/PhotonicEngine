package at.redi2go.photonics.common.iris;

import at.redi2go.photonics.core.Photonics;
import net.irisshaders.iris.shaderpack.materialmap.WorldRenderingSettings;
import net.irisshaders.iris.vertices.BlockSensitiveBufferBuilder;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4588;
import net.minecraft.class_7923;
import java.util.concurrent.atomic.AtomicBoolean;

public final class IrisBlockMaterialBridge {
    private static final AtomicBoolean BRIDGE_LOGGED = new AtomicBoolean();
    private static final AtomicBoolean EMISSIVE_LOGGED = new AtomicBoolean();

    private IrisBlockMaterialBridge() {
    }

    public static boolean begin(
            class_4588 consumer,
            class_2680 blockState,
            class_2338 blockPos,
            String renderPath
    ) {
        if (!(consumer instanceof BlockSensitiveBufferBuilder builder)) {
            return false;
        }

        var blockStateIds = WorldRenderingSettings.INSTANCE.getBlockStateIds();
        if (blockStateIds == null) {
            return false;
        }

        int shaderPackId = blockStateIds.getOrDefault(blockState, -1);
        int lightEmission = blockState.method_26213();
        builder.beginBlock(
                shaderPackId,
                (byte) 0,
                (byte) lightEmission,
                blockPos.method_10263(),
                blockPos.method_10264(),
                blockPos.method_10260()
        );

        if (BRIDGE_LOGGED.compareAndSet(false, true)) {
            Photonics.LOGGER.info(
                    "Photonics v19 Iris material bridge active: path={}, block={}, shaderPackId={}, emission={}",
                    renderPath,
                    class_7923.field_41175.method_10221(blockState.method_26204()),
                    shaderPackId,
                    lightEmission
            );
        }

        if (lightEmission > 0 && EMISSIVE_LOGGED.compareAndSet(false, true)) {
            Photonics.LOGGER.info(
                    "Photonics v19 emissive material captured: path={}, block={}, shaderPackId={}, emission={}",
                    renderPath,
                    class_7923.field_41175.method_10221(blockState.method_26204()),
                    shaderPackId,
                    lightEmission
            );
        }

        return true;
    }

    public static void end(class_4588 consumer, boolean active) {
        if (active && consumer instanceof BlockSensitiveBufferBuilder builder) {
            builder.endBlock();
        }
    }
}
