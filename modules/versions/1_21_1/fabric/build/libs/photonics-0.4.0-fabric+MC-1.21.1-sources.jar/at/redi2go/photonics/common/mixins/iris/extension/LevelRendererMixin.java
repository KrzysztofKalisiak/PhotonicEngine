package at.redi2go.photonics.common.mixins.iris.extension;

import at.redi2go.photonics.common.compat.ContraptionLightsSableBridge;
import at.redi2go.photonics.common.iris.IrisUtil;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Inject(
            method = "renderLevel",
            at = @At("HEAD"),
            order = 900
    )
    public void renderLevel(
            class_9779 deltaTracker,
            boolean bl,
            class_4184 camera,
            class_757 gameRenderer,
            class_765 lightTexture,
            Matrix4f matrix4f,
            Matrix4f matrix4f2,
            CallbackInfo ci
    ) {
        IrisUtil.getPhotonics().ifPresent(extension -> {
            ContraptionLightsSableBridge.captureReceiverMotion();
            extension.onFrameBegin();
        });
    }
}
