package at.redi2go.photonics.impl.mc.world.level;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2784;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2874;
import net.minecraft.class_310;
import net.minecraft.class_3568;
import net.minecraft.class_3610;
import net.minecraft.class_4538;
import net.minecraft.class_4543;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7699;

public class SingleBlockLevelReader implements class_4538 {
    private final class_2680 blockState;

    public SingleBlockLevelReader(class_2680 blockState) {
        this.blockState = Objects.requireNonNull(blockState);
    }

    @Override
    public boolean method_8393(int i, int j) {
        return true;
    }

    @Override
    public @NotNull class_2680 method_8320(@NotNull class_2338 blockPos) {
        return blockState;
    }

    @Override
    public @Nullable class_2586 method_8321(@NotNull class_2338 blockPos) {
        return null;
    }

    @Override
    public @NotNull class_5455 method_30349() {
        return Objects.requireNonNull(class_310.method_1551().field_1687).method_30349();
    }

    @Override
    public @Nullable class_2791 method_8402(int i, int j, @NotNull class_2806 chunkStatus, boolean bl) {
        throw new UnsupportedOperationException("getChunk");
    }

    @Override
    public int method_8624(class_2902.@NotNull class_2903 types, int i, int j) {
        throw new UnsupportedOperationException("getHeight");
    }

    @Override
    public int method_8594() {
        throw new UnsupportedOperationException("getSkyDarken");
    }

    @Override
    public @NotNull class_4543 method_22385() {
        throw new UnsupportedOperationException("getBiomeManager");
    }

    @Override
    public @NotNull class_6880<class_1959> method_22387(int i, int j, int k) {
        throw new UnsupportedOperationException("getUncachedNoiseBiome");
    }

    @Override
    public boolean method_8608() {
        return true;
    }

    @Override
    public int method_8615() {
        throw new UnsupportedOperationException("getSeaLevel");
    }

    @Override
    public @NotNull class_2874 method_8597() {
        throw new UnsupportedOperationException("dimensionType");
    }

    @Override
    public @NotNull class_7699 method_45162() {
        throw new UnsupportedOperationException("enabledFeatures");
    }

    @Override
    public float method_24852(@NotNull class_2350 direction, boolean bl) {
        throw new UnsupportedOperationException("getShade");
    }

    @Override
    public @NotNull class_3568 method_22336() {
        throw new UnsupportedOperationException("getLightEngine");
    }

    @Override
    public @NotNull class_2784 method_8621() {
        throw new UnsupportedOperationException("getWorldBorder");
    }

    @Override
    public @NotNull List<class_265> method_20743(@Nullable class_1297 entity, @NotNull class_238 aABB) {
        throw new UnsupportedOperationException("getEntityCollisions");
    }

    @Override
    public @NotNull class_3610 method_8316(@NotNull class_2338 blockPos) {
        throw new UnsupportedOperationException("getFluidState");
    }
}
