package at.redi2go.photonics.impl.mixins.mc.core;

import at.redi2go.photonics.api.mc.core.IHolderLookup;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_7225.class_7874.class)
public interface HolderLookupProviderMixin extends IHolderLookup.Provider {
}
