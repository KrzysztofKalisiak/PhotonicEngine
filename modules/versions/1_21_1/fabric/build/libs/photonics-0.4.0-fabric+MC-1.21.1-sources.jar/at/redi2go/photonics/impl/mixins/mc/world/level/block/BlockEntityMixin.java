package at.redi2go.photonics.impl.mixins.mc.world.level.block;

import at.redi2go.photonics.api.mc.core.IHolderLookup;
import at.redi2go.photonics.api.mc.nbt.ICompoundTag;
import at.redi2go.photonics.api.mc.world.level.block.IBlockEntity;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2586.class)
@SuppressWarnings("DataFlowIssue")
public abstract class BlockEntityMixin implements IBlockEntity {
    @Shadow
    public abstract class_2487 saveWithFullMetadata(class_7225.class_7874 provider);

    @Override
    public ICompoundTag ph$saveWithFullMetadata(IHolderLookup.Provider provider) {
        return (ICompoundTag) (Object) saveWithFullMetadata((class_7225.class_7874) provider);
    }
}
