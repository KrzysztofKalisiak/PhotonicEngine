package at.redi2go.photonics.core.rendering.world.compiler;

import at.redi2go.photonics.api.mc.Minecraft;
import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.ILevel;
import at.redi2go.photonics.core.Photonics;
import at.redi2go.photonics.core.iris.pipeline.uniform.IDynamicUniformHolder;
import at.redi2go.photonics.core.iris.pipeline.uniform.IUniformHolder;
import at.redi2go.photonics.core.iris.pipeline.uniform.IUniformUpdateFrequency;
import at.redi2go.photonics.core.rendering.RenderingComponent;
import at.redi2go.photonics.core.rendering.SectionCopy;
import at.redi2go.photonics.core.rendering.SectionManager;
import at.redi2go.photonics.core.rendering.UniformUpdater;
import at.redi2go.photonics.core.rendering.WorldOrigin;
import at.redi2go.photonics.core.rendering.world.IgnoredInterruptedException;
import at.redi2go.photonics.core.rendering.world.allocator.WorldAllocator;
import at.redi2go.photonics.core.rendering.world.block.VoxelNormal;
import at.redi2go.photonics.core.rendering.world.block.palette.PaletteTexture;
import at.redi2go.photonics.core.rendering.world.registry.WorldRegistry;
import at.redi2go.photonics.core.rendering.world.tree.BlockMergeMode;
import at.redi2go.photonics.core.rendering.world.tree.VoxelTreeEntry;
import at.redi2go.photonics.core.rendering.world.tree.entries.LightBlockEntry;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import org.joml.RoundingMode;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3f;
import org.joml.Vector3i;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.LongSupplier;

public class WorldCompiler implements Runnable, RenderingComponent {
    public static final int MAX_SECTIONS_PER_RUN = 48;

    private static final int THREAD_POOL_SIZE = 3;
    private static final long SETTLED_DIAGNOSTIC_DELAY_NANOS = 2_000_000_000L;
    private static final long ACTIVE_DIAGNOSTIC_INTERVAL_NANOS = 1_000_000_000L;
    private static final ExecutorService THREAD_POOL;

    private final SectionManager.TaskQueue<ChunkCompiler.BuildResult> taskQueue;
    private final LongSupplier sceneRevisionSupplier;

    private final WorldAllocator worldAllocator;
    private final PaletteTexture paletteTexture;

    private final WorldRegistry registry;

    private final RegionIdManager regionIds = new RegionIdManager();
    private final TreeManager treeManager;

    private final ReentrantLock uploadLock = new ReentrantLock();
    private final Condition uploadDone = uploadLock.newCondition();
    private boolean canUpload = true;

    private Vector3i iorigin = null;
    private WorldOrigin offset = null;

    private final Vector3i minBlock = new Vector3i();
    private final Vector3i maxBlock = new Vector3i();

    private final UniformUpdater uniformUpdater = new UniformUpdater();

    private WorldOrigin mostRecentOrigin = new WorldOrigin(0.0f, 0.0f, 0.0f);
    private Vector3d previousOrigin = null;

    private Vector3f mostRecentMinBounds = new Vector3f();
    private Vector3f mostRecentMaxBounds = new Vector3f();


    private Vector3f mostRecentMinBlock = new Vector3f();
    private Vector3f mostRecentMaxBlock = new Vector3f();

    private int mostRecentBlockContainerScale = 0;
    private boolean mostRecentWorldReady = false;
    private boolean mostRecentWorldSettled = false;
    private boolean mostRecentBlockBoundsFallback = false;

    private long compilationRevision = 0;
    private long mostRecentCompilationRevision = 0;
    private long mostRecentSceneRevision = 0;
    private long lastObservedCompilationRevision = -1;
    private long lastCompilationChangeNanos = 0;
    private long nextActiveDiagnosticNanos = 0;
    private boolean settledDiagnosticLogged = false;

    private int mostRecentCompiledSections = 0;
    private int mostRecentTrackedSections = 0;
    private int mostRecentBuiltBatch = 0;
    private int mostRecentUnloadedBatch = 0;
    private int mostRecentPendingBuilds = 0;
    private int mostRecentPendingUnloads = 0;
    private double mostRecentCompilationMillis = 0.0;

    private final Thread compilerThread;

    public WorldCompiler(
            int depth,
            WorldAllocator worldAllocator,
            PaletteTexture paletteTexture,
            SectionManager.TaskQueue<ChunkCompiler.BuildResult> taskQueue,
            LongSupplier sceneRevisionSupplier,
            WorldRegistry worldRegistry
    ) {
        this.worldAllocator = worldAllocator;
        this.paletteTexture = paletteTexture;

        this.taskQueue = taskQueue;
        this.sceneRevisionSupplier = sceneRevisionSupplier;
        this.registry = worldRegistry;

        this.treeManager = new TreeManager(BlockMergeMode.OVERWRITE, worldAllocator);

        this.compilerThread = new Thread(this, "Photonics World Compiler");
        this.compilerThread.start();
    }

    public WorldOrigin origin() {
        return mostRecentOrigin;
    }

    private void setOrigin(Vector3i origin) {
        this.iorigin = origin;
        this.offset = new WorldOrigin(origin.x, origin.y, origin.z);
    }

    @Override
    public void run() {
        try {
            while (!Thread.interrupted()) {
                taskQueue.awaitTask();
                long compilationStart = System.nanoTime();

                var unloadedSections = taskQueue.drainUnloadQueue();
                var builtSections = taskQueue.drain(MAX_SECTIONS_PER_RUN);
                if (!unloadedSections.isEmpty() || !builtSections.isEmpty()) {
                    // Tree edits release and reuse heap allocations. Block the
                    // render-thread upload before any edit so an old root can
                    // never be paired with a partially rewritten heap.
                    stopUpload();

                    if (!unloadedSections.isEmpty())
                        clearUnloadedSections(unloadedSections);

                    if (!builtSections.isEmpty()) {
                        recenter();

                        clearPendingSections(builtSections);
                        insertSections(builtSections);
                    }

                    writeSections();

                    compilationRevision++;
                    mostRecentCompilationRevision = compilationRevision;
                    mostRecentSceneRevision = sceneRevisionSupplier.getAsLong();
                    mostRecentCompiledSections = regionIds.size();
                    mostRecentTrackedSections = taskQueue.trackedSectionCount();
                    mostRecentBuiltBatch = builtSections.size();
                    mostRecentUnloadedBatch = unloadedSections.size();
                    mostRecentPendingBuilds = taskQueue.pendingCount();
                    mostRecentPendingUnloads = taskQueue.pendingUnloadCount();
                    mostRecentCompilationMillis = (System.nanoTime() - compilationStart) / 1_000_000.0;

                    awaitUpload();

                    registry.freeUnusedObjects();
                }
            }
        } catch (Throwable t) {
            if (t instanceof InterruptedException) return;
            if (IgnoredInterruptedException.shouldIgnore(t)) return;

            Photonics.LOGGER.error(
                    "An error was thrown during world compilation; memory={}",
                    registry.memoryDiagnosticSummary(),
                    t
            );
        }
    }


    // Compiler steps

    private void clearUnloadedSections(List<Vector3i> unloadedSections) {
        if (iorigin == null) return;

        IntSet regions = new IntOpenHashSet(unloadedSections.size());
        for (var section : unloadedSections) {
            regions.add(regionIds.getId(section));
            regionIds.removeRegion(section);
        }

        treeManager.removeRegions(regions);
    }

    private void recenter() throws InterruptedException {
        var newOrigin = WorldOrigin.getAsVector3i();
        if (iorigin == null) {
            setOrigin(newOrigin);
            return;
        }

        if (iorigin.equals(newOrigin)) return;

        stopUpload();

        var offset = iorigin.sub(newOrigin, new Vector3i());
        treeManager.recenter(offset);

        setOrigin(newOrigin);
    }

    private void clearPendingSections(List<ChunkCompiler.BuildResult> sections) {
        IntSet regions = new IntOpenHashSet(sections.size());
        for (var section : sections)
            regions.add(regionIds.getId(section.chunkPos()));

        treeManager.removeRegions(regions);
    }

    private void insertSections(List<ChunkCompiler.BuildResult> sections) {
        BlockSorter blockSorter = new BlockSorter();
        Vector3i blockPos = new Vector3i();

        ILevel level = Minecraft.getLevel();
        if (level == null) return;

        try (var registryLock = registry.lightRegistry().acquireLock()) {
            for (var section : sections) {
                try (section) {
                    blockSorter.reset();

                    var chunkBlockPos = new Vector3i(section.chunkBlockPos())
                            .sub(iorigin);

                    int region = regionIds.getId(section.chunkPos());
                    section.forEachBlock((blockChunkOffset, blockState, blockModel) -> blockSorter.addBlock(
                            chunkBlockPos.add(blockChunkOffset, new Vector3i()),
                            blockState,
                            blockModel
                    ));

                    blockSorter.forEachBlock((block) -> {
                        var parts = block.blockModel().parts();
                        if (parts.isEmpty()) return;

                        var light = registry.lightRegistry().getWeak(block.blockState());

                        for (int i = 0; i < parts.size(); i++) {
                            var part = parts.get(i);

                            blockPos.set(block.x(), block.y(), block.z());
                            blockPos.add(part.offset());
                            blockPos.add(iorigin);

                            var skylight = SectionCopy.compileSkylight(level, IBlockPos.of(blockPos));
                            var entry = part.createEntry(region, skylight, light);

                            blockPos.sub(iorigin);

                            treeManager.insertBlock(
                                    blockPos,
                                    entry
                            );
                        }
                    });
                }
            }
        }
    }

    private void writeSections() throws InterruptedException {
        treeManager.uploadAll(MultiThreadTask::new);
        treeManager.findBounds(minBlock, maxBlock);
    }
    // Uploading

    private void stopUpload() throws InterruptedException {
        uploadLock.lockInterruptibly();

        try {
            canUpload = false;
        } finally {
            uploadLock.unlock();
        }
    }

    private void awaitUpload() throws InterruptedException {
        uploadLock.lockInterruptibly();

        try {
            canUpload = true;
            uniformUpdater.updateNextFrame();
            uploadDone.await();
        } finally {
            uploadLock.unlock();
        }
    }

    @Override
    public void onFrameBegin() {
        uploadLock.lock();

        try {
            if (!canUpload) return;

            worldAllocator.upload();
            paletteTexture.upload();

            var treeMinBounds = treeManager.minBounds();
            var treeMaxBounds = treeManager.maxBounds();
            mostRecentMinBounds = new Vector3f(treeMinBounds);
            mostRecentMaxBounds = new Vector3f(treeMaxBounds);

            mostRecentOrigin = offset == null ? new WorldOrigin(0, 0, 0) : offset;

            boolean compiledBlockBoundsValid = maxBlock.x > minBlock.x
                    && maxBlock.y > minBlock.y
                    && maxBlock.z > minBlock.z;
            boolean blockBoundsFallback = !compiledBlockBoundsValid;
            mostRecentMinBlock = new Vector3f(blockBoundsFallback ? treeMinBounds : minBlock);
            mostRecentMaxBlock = new Vector3f(blockBoundsFallback ? treeMaxBounds : maxBlock);

            int depth = treeManager.depth();
            mostRecentBlockContainerScale = depth == 0 ? 0 : 21 - (depth - (VoxelTreeEntry.BLOCK_CONTAINER_DEPTH) << 1);
            boolean worldReady = depth > 0
                    && mostRecentMaxBlock.x > mostRecentMinBlock.x
                    && mostRecentMaxBlock.y > mostRecentMinBlock.y
                    && mostRecentMaxBlock.z > mostRecentMinBlock.z
                    && mostRecentMaxBounds.x > mostRecentMinBounds.x
                    && mostRecentMaxBounds.y > mostRecentMinBounds.y
                    && mostRecentMaxBounds.z > mostRecentMinBounds.z;

            long now = System.nanoTime();
            if (mostRecentCompilationRevision != lastObservedCompilationRevision) {
                lastObservedCompilationRevision = mostRecentCompilationRevision;
                lastCompilationChangeNanos = now;
                settledDiagnosticLogged = false;
                setWorldSettled(false);
                if (now >= nextActiveDiagnosticNanos) {
                    nextActiveDiagnosticNanos = now + ACTIVE_DIAGNOSTIC_INTERVAL_NANOS;
                    logWorldTracingDiagnostic(false, depth, worldReady, blockBoundsFallback);
                }
            } else if (!settledDiagnosticLogged
                    && lastObservedCompilationRevision > 0
                    && now - lastCompilationChangeNanos >= SETTLED_DIAGNOSTIC_DELAY_NANOS) {
                settledDiagnosticLogged = true;
                setWorldSettled(worldReady);
                logWorldTracingDiagnostic(true, depth, worldReady, blockBoundsFallback);
            }
            mostRecentWorldReady = worldReady;
            if (!worldReady)
                setWorldSettled(false);
            mostRecentBlockBoundsFallback = blockBoundsFallback;

            // Publish tree-dependent uniforms only after every field reflects
            // the tree uploaded above. In particular, a new revision must not
            // receive one frame of environment samples while still "settled".
            uniformUpdater.updateAll();

            uploadDone.signalAll();
        } finally {
            uploadLock.unlock();
        }
    }

    private void setWorldSettled(boolean settled) {
        if (mostRecentWorldSettled == settled) return;

        mostRecentWorldSettled = settled;
        uniformUpdater.updateNextFrame();
    }

    private void logWorldTracingDiagnostic(
            boolean settled,
            int depth,
            boolean worldReady,
            boolean blockBoundsFallback
    ) {
        Photonics.LOGGER.info(
                "Photonics world tracing v127: layoutRevision={}, sceneRevision={}, settled={}, compiledSections={}, trackedSections={}, batchBuilt={}, batchUnloaded={}, pendingBuilds={}, pendingUnloads={}, ready={}, depth={}, blockBounds={}..{}, treeBounds={}..{}, origin={}, boundsSource={}, compileMs={}",
                mostRecentCompilationRevision,
                mostRecentSceneRevision,
                settled,
                mostRecentCompiledSections,
                mostRecentTrackedSections,
                mostRecentBuiltBatch,
                mostRecentUnloadedBatch,
                mostRecentPendingBuilds,
                mostRecentPendingUnloads,
                worldReady,
                depth,
                mostRecentMinBlock,
                mostRecentMaxBlock,
                mostRecentMinBounds,
                mostRecentMaxBounds,
                mostRecentOrigin,
                blockBoundsFallback ? "tree" : "compiled",
                String.format(java.util.Locale.ROOT, "%.3f", mostRecentCompilationMillis)
        );

        if (settled)
            Photonics.LOGGER.info("Photonics memory v72: {}", registry.memoryDiagnosticSummary());
    }

    @Override
    public void registerUniforms(IUniformHolder uniforms) {
        // TODO: Replace this with actual values
        uniforms.uniform1i(IUniformUpdateFrequency.once(), "phFirstBuildTime", () -> 1);
        uniforms.uniform1i(IUniformUpdateFrequency.once(), "phLastBuildTime", () -> 1);
    }

    @Override
    public void registerDynamicUniforms(IDynamicUniformHolder dynamicUniforms) {
        dynamicUniforms.uniform3f(
                "world_offset",
                () -> {
                    var offset = mostRecentOrigin;
                    if (offset == null) return new Vector3f(0f);

                    return toVector3f(offset);
                },
                uniformUpdater.newNotifier()
        );

        dynamicUniforms.uniform3d(
                IUniformUpdateFrequency.perFrame(),
                "delta_world_offset",
                () -> {
                    var previous = previousOrigin;
                    var current = new Vector3d(mostRecentOrigin);

                    previousOrigin = current;
                    if (previous == null || current == null)
                        return new Vector3d();

                    return current.sub(previous, new Vector3d());
                }
        );

        dynamicUniforms.uniform3f("world_min_block", () -> new Vector3f(mostRecentMinBlock), uniformUpdater.newNotifier());
        dynamicUniforms.uniform3f("world_max_block", () -> new Vector3f(mostRecentMaxBlock), uniformUpdater.newNotifier());

        dynamicUniforms.uniform1i("ph_world_ready", () -> mostRecentWorldReady ? 1 : 0, uniformUpdater.newNotifier());
        dynamicUniforms.uniform1i("ph_world_settled", () -> mostRecentWorldSettled ? 1 : 0, uniformUpdater.newNotifier());
        dynamicUniforms.uniform1i(
                "ph_world_revision_slot",
                () -> (int) (mostRecentCompilationRevision & 31L),
                uniformUpdater.newNotifier()
        );
        dynamicUniforms.uniform1i(
                "ph_world_revision",
                () -> (int) mostRecentCompilationRevision,
                uniformUpdater.newNotifier()
        );
        dynamicUniforms.uniform1i(
                "ph_scene_revision",
                () -> (int) mostRecentSceneRevision,
                uniformUpdater.newNotifier()
        );
        dynamicUniforms.uniform3f("world_tree_min", () -> new Vector3f(mostRecentMinBounds), uniformUpdater.newNotifier());
        dynamicUniforms.uniform3f("world_tree_size", () -> new Vector3f(mostRecentMaxBounds).sub(mostRecentMinBounds), uniformUpdater.newNotifier());
        dynamicUniforms.uniform1i("world_block_scale_exp", () -> mostRecentBlockContainerScale, uniformUpdater.newNotifier());

        dynamicUniforms.uniform3f(
                IUniformUpdateFrequency.perFrame(),
                "rt_camera_position",
                () -> {
                    var offset = mostRecentOrigin;
                    if (offset == null) return new Vector3f(0f);

                    var pos = Minecraft.getCameraPos();
                    return toVector3f(offset.applyOffset(new Vector3d(pos.x, pos.y, pos.z)));
                }
        );
    }

    @Override
    public void close() {
        compilerThread.interrupt();
        joinCompilerThread();
    }

    private void joinCompilerThread() {
        boolean interrupted = false;
        while (compilerThread.isAlive()) {
            try {
                compilerThread.join();
            } catch (InterruptedException ignored) {
                interrupted = true;
                compilerThread.interrupt();
            }
        }

        if (interrupted)
            Thread.currentThread().interrupt();
    }

    private static Vector3f toVector3f(Vector3dc vector) {
        return new Vector3f((float) vector.x(), (float) vector.y(), (float) vector.z());
    }

    private static class MultiThreadTask extends CompletableFuture<Void> implements CompilerTask {
        private final AtomicInteger pendingTasks = new AtomicInteger();

        @Override
        public void queueJob(Runnable task) {
            pendingTasks.incrementAndGet();

            THREAD_POOL.execute(() -> {
                try {
                    task.run();
                } finally {
                    if (pendingTasks.decrementAndGet() == 0)
                        complete(null);
                }
            });
        }

        @Override
        public void awaitCompletion() throws InterruptedException {
            boolean interrupted = false;
            try {
                while (pendingTasks.get() != 0) {
                    try {
                        get();
                    } catch (InterruptedException ignored) {
                        interrupted = true;
                    }
                }
            } catch (ExecutionException e) {
                throw new RuntimeException(e);
            }

            if (interrupted) {
                Thread.currentThread().interrupt();
                throw new InterruptedException();
            }
        }
    }

    private static class SingleThreadTask implements CompilerTask {
        @Override
        public void queueJob(Runnable task) {
            task.run();
        }

        @Override
        public void awaitCompletion() {

        }
    }

    static {
        AtomicInteger count = new AtomicInteger(0);
        THREAD_POOL = Executors.newFixedThreadPool(THREAD_POOL_SIZE, (r) ->
                new Thread(r, "Photonics World Worker #" + count.getAndIncrement()));
    }
}
