package at.redi2go.photonics.common.compat;

import at.redi2go.photonics.api.gpu.systems.IRenderSystem;
import at.redi2go.photonics.api.gpu.textures.IGpuTexture3D;
import at.redi2go.photonics.api.gpu.textures.ITextureFormat;
import at.redi2go.photonics.api.gpu.textures.TextureUsage;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.api.shaders.IShaderPack;
import at.redi2go.photonics.common.iris.IrisUtil;
import at.redi2go.photonics.core.Photonics;
import at.redi2go.photonics.core.config.PhConfig;
import at.redi2go.photonics.core.iris.extensions.RestirPipeline;
import at.redi2go.photonics.core.rendering.lights.ExternalLightList;
import at.redi2go.photonics.core.rendering.lights.TracedLightPosition;
import at.redi2go.photonics.core.rendering.sublevel.ExternalSubLevelMotion;
import org.joml.Matrix4d;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3i;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class ContraptionLightsSableBridge {
    private static final int MAX_GEOMETRY_AXIS = 96;
    private static final int MAX_GEOMETRY_VOLUME = 300_000;
    private static final int MAX_GEOMETRY_ATLAS_DEPTH = 512;
    private static final double STATIC_LIGHT_POSITION_EPSILON_SQUARED = 1.0e-6;
    private static final int MOVING_LIGHT_HOLD_FRAMES = 3;

    private static Access access;
    private static boolean unavailable;
    private static boolean activeLogged;
    private static boolean transientFailureLogged;
    private static boolean veilPointLightSuppressionLogged;
    private static int lastUploadedLights = -1;
    private static int lastZeroLuminanceTracedLights = -1;
    private static int lastRejectedMaterials = -1;
    private static int lastActuallyMovingLights = -1;
    private static MotionAccess motionAccess;
    private static boolean motionUnavailable;
    private static boolean motionTransientFailureLogged;
    private static boolean motionActiveLogged;
    private static int lastMotionSubLevels = -1;
    private static int nextMotionToken = 1;
    private static final Map<UUID, Matrix4d> previousWorldToMotionAnchor = new HashMap<>();
    private static final Map<UUID, Vector3i> motionAnchors = new HashMap<>();
    private static final Map<UUID, Integer> motionTokens = new HashMap<>();
    private static final Map<UUID, GeometryRevisionSnapshot> geometryRevisionSnapshots = new HashMap<>();
    private static final Map<SableLightIdentity, Vector3d> publishedLightPositions = new HashMap<>();
    private static final Map<SableLightIdentity, Integer> movingLightHoldFrames = new HashMap<>();

    private static IGpuTexture3D geometryTexture;
    private static List<GeometryKey> geometryKeys = List.of();
    private static List<GeometryLayoutKey> geometryLayoutKeys = List.of();
    private static int[] geometryOffsets = new int[0];
    private static byte[] geometryPayload = new byte[0];
    private static int geometryWidth;
    private static int geometryHeight;
    private static int geometryDepth;
    private static int geometryRebuilds;
    private static int geometryUnchangedScans;

    private ContraptionLightsSableBridge() {
    }

    public static void capture() {
        if (unavailable)
            return;

        var level = class_310.method_1551().field_1687;
        if (level == null) {
            clear();
            return;
        }

        try {
            var bridgeAccess = access();
            var transformAccess = motionAccess();
            Map<?, ?> states = (Map<?, ?>) bridgeAccess.states.get(null);
            var shaderPack = IShaderPack.getCurrentPack().orElse(null);
            var lightRegistry = PhConfig.getLightRegistry();
            var lights = new ArrayList<TracedLightPosition>();
            var replacedBlockPositions = new HashSet<Vector3i>();
            var seenLightIdentities = new HashSet<SableLightIdentity>();
            int sourceLights = 0;
            int zeroLuminanceTracedLights = 0;
            int rejectedMaterials = 0;
            int actuallyMovingLights = 0;
            String firstValidationIssue = null;

            for (var mapEntry : states.entrySet()) {
                if (!(mapEntry.getKey() instanceof UUID uniqueId))
                    continue;

                Object state = mapEntry.getValue();
                Object subLevel = transformAccess.subLevel.get(state);
                if (subLevel == null)
                    continue;

                int minX = transformAccess.minX.getInt(state);
                int minY = transformAccess.minY.getInt(state);
                int minZ = transformAccess.minZ.getInt(state);
                Object pose = transformAccess.renderPose.invoke(subLevel);
                Matrix4f worldToGrid = new Matrix4f((Matrix4f) transformAccess.buildWorldToLocal.invoke(
                        null,
                        pose,
                        minX,
                        minY,
                        minZ
                ));
                if (!worldToGrid.isFinite() || Math.abs(worldToGrid.determinant()) < 0.000001f)
                    continue;
                Matrix4d gridToWorld = new Matrix4d(worldToGrid).invert();

                int[] lightX = (int[]) bridgeAccess.lightX.get(state);
                int[] lightY = (int[]) bridgeAccess.lightY.get(state);
                int[] lightZ = (int[]) bridgeAccess.lightZ.get(state);
                int[] lightLum = (int[]) bridgeAccess.lightLum.get(state);

                if (lightX == null || lightY == null || lightZ == null || lightLum == null)
                    continue;

                int count = Math.min(
                        Math.min(lightX.length, lightY.length),
                        Math.min(lightZ.length, lightLum.length)
                );
                sourceLights += count;

                for (int i = 0; i < count; i++) {
                    var localPos = new class_2338(lightX[i], lightY[i], lightZ[i]);
                    var blockState = level.method_8320(localPos);
                    var apiBlockState = (IBlockState) (Object) blockState;
                    var lightInfo = lightRegistry.get(apiBlockState);

                    if (lightInfo == null || !lightInfo.isTraced()) {
                        rejectedMaterials++;
                        if (firstValidationIssue == null)
                            firstValidationIssue = "rejectedMaterial id=" + uniqueId
                                    + " local=" + localPos + " sourceLuminance=" + lightLum[i]
                                    + " state=" + blockState;
                        continue;
                    }

                    // Photonics' state-aware material registry is authoritative.
                    // Contraption Lights can transiently publish zero luminance
                    // for a source that is still a traced emissive block.
                    if (lightLum[i] <= 0) {
                        zeroLuminanceTracedLights++;
                        if (firstValidationIssue == null)
                            firstValidationIssue = "zeroLuminanceTraced id=" + uniqueId
                                    + " local=" + localPos + " state=" + blockState;
                    }

                    var worldPosition = gridToWorld.transformPosition(
                            lightX[i] - minX + 0.5d,
                            lightY[i] - minY + 0.5d,
                            lightZ[i] - minZ + 0.5d,
                            new Vector3d()
                    );
                    var identity = new SableLightIdentity(uniqueId, lightX[i], lightY[i], lightZ[i]);
                    seenLightIdentities.add(identity);

                    Vector3d publishedPosition = publishedLightPositions.get(identity);
                    boolean previousPositionValid = publishedPosition != null;
                    Vector3d previousWorldPosition = previousPositionValid
                            ? new Vector3d(publishedPosition)
                            : new Vector3d(worldPosition);
                    boolean moved = !previousPositionValid
                            || publishedPosition.distanceSquared(worldPosition)
                            > STATIC_LIGHT_POSITION_EPSILON_SQUARED;
                    if (!moved)
                        worldPosition.set(publishedPosition);

                    int movingFrames = moved
                            ? MOVING_LIGHT_HOLD_FRAMES
                            : Math.max(0, movingLightHoldFrames.getOrDefault(identity, 0) - 1);
                    if (movingFrames > 0) {
                        movingLightHoldFrames.put(identity, movingFrames);
                        actuallyMovingLights++;
                    } else {
                        movingLightHoldFrames.remove(identity);
                    }
                    publishedLightPositions.put(identity, new Vector3d(worldPosition));

                    int blockId = shaderPack == null ? -1 : shaderPack.getBlockId(apiBlockState);
                    lights.add(new TracedLightPosition(
                            blockId,
                            worldPosition,
                            apiBlockState,
                            lightInfo,
                            identity,
                            movingFrames > 0,
                            previousWorldPosition,
                            previousPositionValid
                    ));
                    replacedBlockPositions.add(new Vector3i(lightX[i], lightY[i], lightZ[i]));
                }
            }

            publishedLightPositions.keySet().retainAll(seenLightIdentities);
            movingLightHoldFrames.keySet().retainAll(seenLightIdentities);
            ExternalLightList.submit(lights, replacedBlockPositions);
            logCapture(
                    states.size(),
                    sourceLights,
                    lights.size(),
                    actuallyMovingLights,
                    zeroLuminanceTracedLights,
                    rejectedMaterials,
                    firstValidationIssue
            );
            transientFailureLogged = false;
        } catch (InvocationTargetException | RuntimeException exception) {
            ExternalLightList.clear();
            if (!transientFailureLogged) {
                transientFailureLogged = true;
                Photonics.LOGGER.warn(
                        "Photonics v24 temporarily skipped a frame-aligned Contraption Lights/Sable moving-light capture",
                        exception
                );
            }
        } catch (ReflectiveOperationException | LinkageError exception) {
            unavailable = true;
            ExternalLightList.clear();
            Photonics.LOGGER.warn(
                    "Photonics v24 disabled the optional frame-aligned Contraption Lights/Sable moving-light bridge",
                    exception
            );
        }
    }

    public static float filterVeilPointLightBrightness(float brightness) {
        var extension = IrisUtil.getPhotonics().orElse(null);
        if (!(extension instanceof RestirPipeline restirPipeline)
                || !restirPipeline.isBlockLightEnabled())
            return brightness;

        if (!veilPointLightSuppressionLogged) {
            veilPointLightSuppressionLogged = true;
            Photonics.LOGGER.info(
                    "Photonics v31 suppressing duplicate Contraption Lights/Veil point-light energy; Sable emissive material and bloom remain enabled"
            );
        }

        return 0.0f;
    }

    public static void clear() {
        ExternalLightList.clear();
        ExternalSubLevelMotion.clear();
        previousWorldToMotionAnchor.clear();
        motionAnchors.clear();
        motionTokens.clear();
        geometryRevisionSnapshots.clear();
        publishedLightPositions.clear();
        movingLightHoldFrames.clear();
        nextMotionToken = 1;
        if (lastUploadedLights > 0)
            Photonics.LOGGER.info("Photonics v24 Sable moving lights: {} -> 0", lastUploadedLights);
        if (lastMotionSubLevels > 0)
            Photonics.LOGGER.info("Photonics v24 Sable receiver motion: {} -> 0", lastMotionSubLevels);
        lastUploadedLights = 0;
        lastActuallyMovingLights = 0;
        lastMotionSubLevels = 0;
        lastZeroLuminanceTracedLights = -1;
        lastRejectedMaterials = -1;
        resetGeometryAtlas();
    }

    public static void captureReceiverMotion() {
        if (motionUnavailable || unavailable)
            return;

        try {
            var lightAccess = access();
            Map<?, ?> states = (Map<?, ?>) lightAccess.states.get(null);
            var bridgeAccess = motionAccess();
            var level = class_310.method_1551().field_1687;
            if (level == null)
                return;
            var candidates = new ArrayList<MotionCandidate>();
            var currentWorldToMotionAnchor = new HashMap<UUID, Matrix4d>();

            for (var mapEntry : states.entrySet()) {
                if (!(mapEntry.getKey() instanceof UUID uniqueId))
                    continue;

                Object state = mapEntry.getValue();
                Object subLevel = bridgeAccess.subLevel.get(state);
                if (subLevel == null)
                    continue;

                int sizeX = bridgeAccess.sizeX.getInt(state);
                int sizeY = bridgeAccess.sizeY.getInt(state);
                int sizeZ = bridgeAccess.sizeZ.getInt(state);
                if (sizeX <= 0 || sizeY <= 0 || sizeZ <= 0)
                    continue;

                int minX = bridgeAccess.minX.getInt(state);
                int minY = bridgeAccess.minY.getInt(state);
                int minZ = bridgeAccess.minZ.getInt(state);
                Object pose = bridgeAccess.renderPose.invoke(subLevel);
                Matrix4f currentGrid = new Matrix4f((Matrix4f) bridgeAccess.buildWorldToLocal.invoke(
                        null,
                        pose,
                        minX,
                        minY,
                        minZ
                ));
                if (!currentGrid.isFinite() || Math.abs(currentGrid.determinant()) < 0.000001f)
                    continue;

                Vector3i anchor = motionAnchors.computeIfAbsent(
                        uniqueId,
                        ignored -> new Vector3i(minX, minY, minZ)
                );
                Matrix4d currentAnchor = new Matrix4d(currentGrid);
                currentAnchor.m30(currentAnchor.m30() + (double) minX - anchor.x);
                currentAnchor.m31(currentAnchor.m31() + (double) minY - anchor.y);
                currentAnchor.m32(currentAnchor.m32() + (double) minZ - anchor.z);

                Matrix4d previous = previousWorldToMotionAnchor.get(uniqueId);
                if (previous == null || !previous.isFinite() || Math.abs(previous.determinant()) < 0.000001d)
                    previous = currentAnchor;

                Matrix4d currentToPreviousDouble = new Matrix4d(previous)
                        .invert()
                        .mul(currentAnchor);
                if (!currentToPreviousDouble.isFinite())
                    continue;
                Matrix4f currentToPrevious = new Matrix4f(currentToPreviousDouble);
                Matrix4d previousToCurrentGridDouble = new Matrix4d(currentGrid)
                        .mul(new Matrix4d(currentToPreviousDouble).invert());
                if (!previousToCurrentGridDouble.isFinite())
                    continue;
                Matrix4f previousToCurrentGrid = new Matrix4f(previousToCurrentGridDouble);

                var emissiveCells = bridgeAccess.emissiveCells(
                        state,
                        minX,
                        minY,
                        minZ,
                        sizeX,
                        sizeY,
                        sizeZ
                );

                candidates.add(new MotionCandidate(
                        uniqueId,
                        currentGrid,
                        currentToPrevious,
                        previousToCurrentGrid,
                        level,
                        minX,
                        minY,
                        minZ,
                        sizeX,
                        sizeY,
                        sizeZ,
                        (byte[]) bridgeAccess.occupancy.get(state),
                        emissiveCells
                ));
                currentWorldToMotionAnchor.put(uniqueId, currentAnchor);
            }

            candidates.sort(Comparator.comparing(MotionCandidate::uniqueId));
            if (candidates.size() > ExternalSubLevelMotion.MAX_SUBLEVELS)
                candidates.subList(ExternalSubLevelMotion.MAX_SUBLEVELS, candidates.size()).clear();

            int[] atlasOffsets = updateGeometryAtlas(candidates);
            var subLevels = new ArrayList<ExternalSubLevelMotion.SubLevel>(candidates.size());
            for (int i = 0; i < candidates.size(); i++) {
                MotionCandidate candidate = candidates.get(i);
                subLevels.add(new ExternalSubLevelMotion.SubLevel(
                        motionToken(candidate),
                        candidate.currentWorldToGrid(),
                        candidate.currentWorldToPreviousWorld(),
                        candidate.previousWorldToCurrentGrid(),
                        new Vector3i(candidate.sizeX(), candidate.sizeY(), candidate.sizeZ()),
                        atlasOffsets[i],
                        candidate.emissiveCells()
                ));
            }

            int occupancyTexture = geometryTexture == null
                    ? 0
                    : IrisUtil.getTextureHandle(geometryTexture);
            ExternalSubLevelMotion.submit(occupancyTexture, subLevels);
            previousWorldToMotionAnchor.keySet().retainAll(currentWorldToMotionAnchor.keySet());
            previousWorldToMotionAnchor.putAll(currentWorldToMotionAnchor);
            motionAnchors.keySet().retainAll(currentWorldToMotionAnchor.keySet());
            geometryRevisionSnapshots.keySet().retainAll(currentWorldToMotionAnchor.keySet());
            logMotionCapture(subLevels.size());
            motionTransientFailureLogged = false;
        } catch (InvocationTargetException | RuntimeException exception) {
            ExternalSubLevelMotion.clear();
            previousWorldToMotionAnchor.clear();
            motionAnchors.clear();
            if (!motionTransientFailureLogged) {
                motionTransientFailureLogged = true;
                Photonics.LOGGER.warn(
                        "Photonics v24 temporarily skipped Sable receiver-motion/geometry capture",
                        exception
                );
            }
        } catch (ReflectiveOperationException | LinkageError exception) {
            motionUnavailable = true;
            ExternalSubLevelMotion.clear();
            previousWorldToMotionAnchor.clear();
            motionAnchors.clear();
            Photonics.LOGGER.warn(
                    "Photonics v24 disabled the optional Sable receiver-motion/geometry bridge",
                    exception
            );
        }
    }

    private static int[] updateGeometryAtlas(List<MotionCandidate> candidates) {
        var keys = new ArrayList<GeometryKey>(candidates.size());
        var layoutKeys = new ArrayList<GeometryLayoutKey>(candidates.size());
        for (MotionCandidate candidate : candidates) {
            keys.add(geometryKey(candidate));
            layoutKeys.add(new GeometryLayoutKey(
                    candidate.uniqueId(),
                    candidate.minX(),
                    candidate.minY(),
                    candidate.minZ(),
                    candidate.sizeX(),
                    candidate.sizeY(),
                    candidate.sizeZ()
            ));
        }

        if (keys.equals(geometryKeys))
            return geometryOffsets;

        int[] offsets = new int[candidates.size()];
        Arrays.fill(offsets, -1);
        int width = 1;
        int height = 1;
        int depth = 0;
        int accepted = 0;

        for (int i = 0; i < candidates.size(); i++) {
            MotionCandidate candidate = candidates.get(i);
            long volume = (long) candidate.sizeX() * candidate.sizeY() * candidate.sizeZ();
            if (candidate.sizeX() > MAX_GEOMETRY_AXIS
                    || candidate.sizeY() > MAX_GEOMETRY_AXIS
                    || candidate.sizeZ() > MAX_GEOMETRY_AXIS
                    || volume > MAX_GEOMETRY_VOLUME
                    || depth + candidate.sizeZ() > MAX_GEOMETRY_ATLAS_DEPTH)
                continue;

            offsets[i] = depth;
            depth += candidate.sizeZ();
            width = Math.max(width, candidate.sizeX());
            height = Math.max(height, candidate.sizeY());
            accepted++;
        }

        if (accepted == 0) {
            closeGeometryTexture();
            geometryKeys = List.copyOf(keys);
            geometryLayoutKeys = List.copyOf(layoutKeys);
            geometryOffsets = offsets;
            geometryPayload = new byte[0];
            return offsets;
        }

        width = (width + 3) & ~3;
        byte[] payload = new byte[width * height * depth];
        int receiverCells = 0;
        int occluderCells = 0;
        var mutablePos = new class_2338.class_2339();

        for (int i = 0; i < candidates.size(); i++) {
            int atlasZ = offsets[i];
            if (atlasZ < 0)
                continue;

            MotionCandidate candidate = candidates.get(i);
            for (int z = 0; z < candidate.sizeZ(); z++) {
                for (int y = 0; y < candidate.sizeY(); y++) {
                    for (int x = 0; x < candidate.sizeX(); x++) {
                        mutablePos.method_10103(
                                candidate.minX() + x,
                                candidate.minY() + y,
                                candidate.minZ() + z
                        );
                        class_2680 state = candidate.blockGetter().method_8320(mutablePos);
                        int cellFlags = 0;
                        if (!state.method_26215() || !state.method_26227().method_15769())
                            cellFlags |= 0x40;
                        if (isCoarseOccluder(candidate.blockGetter(), mutablePos, state))
                            cellFlags |= 0x80;
                        if (cellFlags == 0)
                            continue;

                        int index = ((atlasZ + z) * height + y) * width + x;
                        payload[index] = (byte) cellFlags;
                        receiverCells++;
                        if ((cellFlags & 0x80) != 0)
                            occluderCells++;
                    }
                }
            }
        }

        boolean unchanged = geometryTexture != null
                && !geometryTexture.ph$isClosed()
                && geometryWidth == width
                && geometryHeight == height
                && geometryDepth == depth
                && layoutKeys.equals(geometryLayoutKeys)
                && Arrays.equals(offsets, geometryOffsets)
                && Arrays.equals(payload, geometryPayload);
        if (unchanged) {
            geometryKeys = List.copyOf(keys);
            geometryUnchangedScans++;
            if (Integer.bitCount(geometryUnchangedScans) == 1) {
                Photonics.LOGGER.info(
                        "Photonics v27 skipped unchanged Sable geometry upload: skipped={}, subLevels={}, size={}x{}x{}, payloadHash={}",
                        geometryUnchangedScans,
                        accepted,
                        width,
                        height,
                        depth,
                        Integer.toUnsignedString(Arrays.hashCode(payload), 16)
                );
            }
            return geometryOffsets;
        }

        ByteBuffer data = ByteBuffer.allocateDirect(payload.length);
        data.put(payload);
        data.flip();
        if (geometryTexture == null) {
            geometryTexture = IRenderSystem.getDevice().ph$createTexture3D(
                    () -> "Photonics Sable Geometry Atlas",
                    TextureUsage.TEXTURE_BINDING | TextureUsage.COPY_DST,
                    ITextureFormat.r8(),
                    width,
                    height,
                    depth,
                    1
            );
        } else if (geometryWidth != width || geometryHeight != height || geometryDepth != depth) {
            geometryTexture.ph$resize(new Vector3i(width, height, depth));
        }

        geometryWidth = width;
        geometryHeight = height;
        geometryDepth = depth;
        IRenderSystem.getDevice().ph$createCommandEncoder().ph$writeToTexture(
                geometryTexture,
                data,
                new Vector3i(),
                new Vector3i(width, height, depth)
        );
        geometryRebuilds++;
        Photonics.LOGGER.info(
                "Photonics v27 Sable geometry atlas rebuilt: rebuild={}, subLevels={}, receiverCells={}, occluderCells={}, size={}x{}x{}, precision=solid-block-cell, payloadHash={}",
                geometryRebuilds,
                accepted,
                receiverCells,
                occluderCells,
                width,
                height,
                depth,
                Integer.toUnsignedString(Arrays.hashCode(payload), 16)
        );
        geometryKeys = List.copyOf(keys);
        geometryLayoutKeys = List.copyOf(layoutKeys);
        geometryOffsets = offsets;
        geometryPayload = payload;
        return offsets;
    }

    private static boolean isCoarseOccluder(class_1922 level, class_2338 pos, class_2680 state) {
        if (state.method_26215() || state.method_26213() > 0 || !state.method_26227().method_15769())
            return false;

        var collision = state.method_26220(level, pos);
        if (collision.method_1110())
            return false;

        return state.method_26225() && class_2248.method_9614(collision);
    }

    private static void resetGeometryAtlas() {
        geometryKeys = List.of();
        geometryLayoutKeys = List.of();
        geometryOffsets = new int[0];
        geometryPayload = new byte[0];
        geometryRebuilds = 0;
        geometryUnchangedScans = 0;
        closeGeometryTexture();
    }

    private static void closeGeometryTexture() {
        if (geometryTexture != null && !geometryTexture.ph$isClosed())
            geometryTexture.close();
        geometryTexture = null;
        geometryWidth = 0;
        geometryHeight = 0;
        geometryDepth = 0;
    }

    private static GeometryKey geometryKey(MotionCandidate candidate) {
        byte[] currentRevision = candidate.occupancyRevision() == null
                ? new byte[0]
                : candidate.occupancyRevision();
        GeometryRevisionSnapshot cached = geometryRevisionSnapshots.get(candidate.uniqueId());
        ByteBuffer revisionContent;
        if (cached != null && Arrays.equals(cached.sourceRevision(), currentRevision)) {
            revisionContent = cached.content();
        } else {
            byte[] revisionSnapshot = Arrays.copyOf(currentRevision, currentRevision.length);
            revisionContent = ByteBuffer.wrap(revisionSnapshot).asReadOnlyBuffer();
            geometryRevisionSnapshots.put(
                    candidate.uniqueId(),
                    new GeometryRevisionSnapshot(revisionSnapshot, revisionContent)
            );
        }

        return new GeometryKey(
                candidate.uniqueId(),
                candidate.minX(),
                candidate.minY(),
                candidate.minZ(),
                candidate.sizeX(),
                candidate.sizeY(),
                candidate.sizeZ(),
                revisionContent
        );
    }

    private static int motionToken(MotionCandidate candidate) {
        Integer current = motionTokens.get(candidate.uniqueId());
        if (current != null)
            return current;

        int token = nextMotionToken++;
        if (nextMotionToken > 0xffff)
            nextMotionToken = 1;
        motionTokens.put(candidate.uniqueId(), token);
        return token;
    }

    private static void logMotionCapture(int subLevels) {
        if (!motionActiveLogged && subLevels > 0) {
            motionActiveLogged = true;
            Photonics.LOGGER.info(
                    "Photonics v35 Sable receiver motion active: subLevels={}, classifier=receiver-cell-atlas+emissive-cells, localVisibility=surface-biased-solid-block-cell, temporalTransform=stable-anchor-double-compose",
                    subLevels
            );
        }

        if (subLevels != lastMotionSubLevels) {
            Photonics.LOGGER.info(
                    "Photonics v24 Sable receiver motion: {} -> {}",
                    Math.max(lastMotionSubLevels, 0),
                    subLevels
            );
            lastMotionSubLevels = subLevels;
        }
    }

    private static void logCapture(
            int structures,
            int sourceLights,
            int uploadedLights,
            int actuallyMovingLights,
            int zeroLuminanceTracedLights,
            int rejectedMaterials,
            String firstValidationIssue
    ) {
        if (!activeLogged && structures > 0) {
            activeLogged = true;
            Photonics.LOGGER.info(
                    "Photonics v28 frame-aligned Contraption Lights/Sable moving-light bridge active: structures={}, sourceLights={}, uploadedLights={}, proposalBudget=adaptive-half-candidates",
                    structures,
                    sourceLights,
                    uploadedLights
            );
        }

        if (uploadedLights != lastUploadedLights) {
            Photonics.LOGGER.info(
                    "Photonics v24 Sable moving lights: {} -> {} (structures={}, sourceLights={})",
                    Math.max(lastUploadedLights, 0),
                    uploadedLights,
                    structures,
                    sourceLights
            );
            lastUploadedLights = uploadedLights;
        }

        if (actuallyMovingLights != lastActuallyMovingLights) {
            Photonics.LOGGER.info(
                    "Photonics v35 Sable reactive lights: moving={}, stationary={}, uploaded={}",
                    actuallyMovingLights,
                    Math.max(0, uploadedLights - actuallyMovingLights),
                    uploadedLights
            );
            lastActuallyMovingLights = actuallyMovingLights;
        }

        if (zeroLuminanceTracedLights != lastZeroLuminanceTracedLights
                || rejectedMaterials != lastRejectedMaterials) {
            Photonics.LOGGER.info(
                    "Photonics v28 Sable source validation: zeroLuminanceButTraced={}, rejectedMaterial={}, firstIssue={}",
                    zeroLuminanceTracedLights,
                    rejectedMaterials,
                    firstValidationIssue == null ? "none" : firstValidationIssue
            );
            lastZeroLuminanceTracedLights = zeroLuminanceTracedLights;
            lastRejectedMaterials = rejectedMaterials;
        }
    }

    private static Access access() throws ReflectiveOperationException {
        if (access == null)
            access = new Access();
        return access;
    }

    private static MotionAccess motionAccess() throws ReflectiveOperationException {
        if (motionAccess == null)
            motionAccess = new MotionAccess();
        return motionAccess;
    }

    private record SableLightIdentity(UUID subLevelId, int x, int y, int z) {
    }

    private record MotionCandidate(
            UUID uniqueId,
            Matrix4f currentWorldToGrid,
            Matrix4f currentWorldToPreviousWorld,
            Matrix4f previousWorldToCurrentGrid,
            class_1922 blockGetter,
            int minX,
            int minY,
            int minZ,
            int sizeX,
            int sizeY,
            int sizeZ,
            byte[] occupancyRevision,
            List<Vector3i> emissiveCells
    ) {
    }

    private record GeometryKey(
            UUID uniqueId,
            int minX,
            int minY,
            int minZ,
            int sizeX,
            int sizeY,
            int sizeZ,
            ByteBuffer occupancyRevision
    ) {
    }

    private record GeometryRevisionSnapshot(byte[] sourceRevision, ByteBuffer content) {
    }

    private record GeometryLayoutKey(
            UUID uniqueId,
            int minX,
            int minY,
            int minZ,
            int sizeX,
            int sizeY,
            int sizeZ
    ) {
    }

    private static final class Access {
        private final Field states;
        private final Field lightX;
        private final Field lightY;
        private final Field lightZ;
        private final Field lightLum;

        private Access() throws ReflectiveOperationException {
            var lightingClass = Class.forName(
                    "xyz.atmerek.contraptionlights.veil.sublevel.SubLevelVeilLighting"
            );
            var stateClass = Class.forName(
                    "xyz.atmerek.contraptionlights.veil.sublevel.SubLevelVeilLighting$State"
            );

            states = accessible(lightingClass.getDeclaredField("states"));
            lightX = accessible(stateClass.getDeclaredField("lightX"));
            lightY = accessible(stateClass.getDeclaredField("lightY"));
            lightZ = accessible(stateClass.getDeclaredField("lightZ"));
            lightLum = accessible(stateClass.getDeclaredField("lightLum"));
        }

        private static Field accessible(Field field) {
            field.setAccessible(true);
            return field;
        }
    }

    private static final class MotionAccess {
        private final Field subLevel;
        private final Field occupancy;
        private final Field minX;
        private final Field minY;
        private final Field minZ;
        private final Field sizeX;
        private final Field sizeY;
        private final Field sizeZ;
        private final Field lightX;
        private final Field lightY;
        private final Field lightZ;
        private final Method renderPose;
        private final Method buildWorldToLocal;

        private MotionAccess() throws ReflectiveOperationException {
            var lightingClass = Class.forName(
                    "xyz.atmerek.contraptionlights.veil.sublevel.SubLevelVeilLighting"
            );
            var stateClass = Class.forName(
                    "xyz.atmerek.contraptionlights.veil.sublevel.SubLevelVeilLighting$State"
            );
            var subLevelClass = Class.forName("dev.ryanhcode.sable.sublevel.ClientSubLevel");
            var poseClass = Class.forName("dev.ryanhcode.sable.companion.math.Pose3dc");

            subLevel = accessible(stateClass.getDeclaredField("subLevel"));
            occupancy = accessible(stateClass.getDeclaredField("occupancy"));
            minX = accessible(stateClass.getDeclaredField("minX"));
            minY = accessible(stateClass.getDeclaredField("minY"));
            minZ = accessible(stateClass.getDeclaredField("minZ"));
            sizeX = accessible(stateClass.getDeclaredField("sizeX"));
            sizeY = accessible(stateClass.getDeclaredField("sizeY"));
            sizeZ = accessible(stateClass.getDeclaredField("sizeZ"));
            lightX = accessible(stateClass.getDeclaredField("lightX"));
            lightY = accessible(stateClass.getDeclaredField("lightY"));
            lightZ = accessible(stateClass.getDeclaredField("lightZ"));
            renderPose = subLevelClass.getMethod("renderPose");
            buildWorldToLocal = accessible(lightingClass.getDeclaredMethod(
                    "buildWorldToLocal",
                    poseClass,
                    int.class,
                    int.class,
                    int.class
            ));
        }

        private List<Vector3i> emissiveCells(
                Object state,
                int minX,
                int minY,
                int minZ,
                int sizeX,
                int sizeY,
                int sizeZ
        ) throws IllegalAccessException {
            int[] xs = (int[]) lightX.get(state);
            int[] ys = (int[]) lightY.get(state);
            int[] zs = (int[]) lightZ.get(state);
            if (xs == null || ys == null || zs == null)
                return List.of();

            int count = Math.min(xs.length, Math.min(ys.length, zs.length));
            var result = new ArrayList<Vector3i>(count);
            for (int i = 0; i < count; i++) {
                int x = xs[i] - minX;
                int y = ys[i] - minY;
                int z = zs[i] - minZ;
                if (x >= 0 && y >= 0 && z >= 0 && x < sizeX && y < sizeY && z < sizeZ)
                    result.add(new Vector3i(x, y, z));
            }
            return result;
        }

        private static Field accessible(Field field) {
            field.setAccessible(true);
            return field;
        }

        private static Method accessible(Method method) {
            method.setAccessible(true);
            return method;
        }
    }
}
