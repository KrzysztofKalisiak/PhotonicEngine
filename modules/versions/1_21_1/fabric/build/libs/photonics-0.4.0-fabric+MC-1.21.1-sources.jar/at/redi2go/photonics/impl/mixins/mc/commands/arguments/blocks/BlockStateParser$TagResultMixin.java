package at.redi2go.photonics.impl.mixins.mc.commands.arguments.blocks;

import at.redi2go.photonics.api.mc.commands.arguments.blocks.IBlockStateParser;
import at.redi2go.photonics.api.mc.core.IHolderSet;
import at.redi2go.photonics.api.mc.nbt.ICompoundTag;
import at.redi2go.photonics.api.mc.world.level.IBlock;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2487;
import net.minecraft.class_6885;

@SuppressWarnings("unchecked")
@Mixin(class_2259.class_7212.class)
public abstract class TagResultMixin implements IBlockStateParser.TagResult  {
    @Shadow
    public abstract class_6885<class_2248> tag();

    @Shadow
    public abstract Map<String, String> vagueProperties();

    @Shadow
    public abstract @Nullable class_2487 nbt();

    @Override
    public IHolderSet<IBlock> ph$tag() {
        return (IHolderSet) tag();
    }

    @Override
    public Map<String, String> ph$vagueProperties() {
        return vagueProperties();
    }

    @Override
    public @Nullable ICompoundTag ph$nbt() {
        return (ICompoundTag) (Object) nbt();
    }
}
