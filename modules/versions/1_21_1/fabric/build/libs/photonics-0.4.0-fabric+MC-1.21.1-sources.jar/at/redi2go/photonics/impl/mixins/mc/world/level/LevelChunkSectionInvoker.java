package at.redi2go.photonics.impl.mixins.mc.world.level;

import net.minecraft.class_2826;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2826.class)
public interface LevelChunkSectionInvoker {
    @Invoker("<init>")
    static class_2826 copySection(class_2826 toCopy) {
        throw new AssertionError();
    }
}
