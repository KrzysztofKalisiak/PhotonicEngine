package at.redi2go.photonics.impl.mixins.mc.core;

import at.redi2go.photonics.api.mc.core.IBlockPos;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value = IBlockPos.class)
public interface IBlockPosImpl {
    @Overwrite
    static IBlockPos zero() {
        return (IBlockPos) new class_2338(0, 0, 0);
    }

    @Overwrite
    static IBlockPos of(int x, int y, int z) {
        return (IBlockPos) new class_2338(x, y, z);
    }
}
