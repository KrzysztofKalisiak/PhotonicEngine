package at.redi2go.photonics.common.meshing;

import at.redi2go.photonics.api.mc.Id;
import at.redi2go.photonics.api.mc.core.IBlockPos;
import at.redi2go.photonics.api.mc.world.level.IBlockAndTintGetter;
import at.redi2go.photonics.api.mc.world.level.IBlockState;
import at.redi2go.photonics.common.iris.IrisUtil;
import at.redi2go.photonics.core.rendering.world.bakery.BlockBuilder;
import at.redi2go.photonics.core.rendering.world.bakery.BlockMesher;
import org.joml.Vector3i;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1059;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_777;

public class MinecraftBlockMesher implements BlockMesher<McMeshState> {
    private static final Id BLOCK_ATLAS = (Id) (Object) class_1059.field_5275;
    private static final class_2350[] DIRECTIONS = class_2350.values();

    private final ThreadLocal<class_5819> random = ThreadLocal.withInitial(class_5819::method_43047);

    @Override
    public McMeshState extractMeshState(
            Vector3i blockChunkOffset,
            IBlockPos pos,
            IBlockState blockState,
            IBlockAndTintGetter blockAndTintGetter
    ) {
        class_2680 mcState = (class_2680) blockState;
        if (mcState.method_26217() != class_2464.field_11458) return McMeshState.EMPTY;

        var model = class_310.method_1551().method_1541().method_3349(mcState);
        var randomSource = random.get();
        var quads = new ArrayList<class_777>();

        randomSource.method_43052(mcState.method_26190((class_2338) pos));
        quads.addAll(model.method_4707(mcState, null, randomSource));

        for (class_2350 direction : DIRECTIONS) {
            randomSource.method_43052(mcState.method_26190((class_2338) pos));
            quads.addAll(model.method_4707(mcState, direction, randomSource));
        }

        if (quads.isEmpty()) return McMeshState.EMPTY;

        return new McMeshState(IrisUtil.getBlockId(mcState), List.copyOf(quads));
    }

    @Override
    public void meshBlock(
            McMeshState meshState,
            Vector3i blockChunkOffset,
            IBlockPos pos,
            IBlockState blockState,
            IBlockAndTintGetter blockAndTintGetter,
            BlockBuilder blockBuilder
    ) {
        if (meshState == McMeshState.EMPTY) return;

        class_2680 mcState = (class_2680) blockState;
        class_2338 mcPos = (class_2338) pos;
        class_1920 level = (class_1920) blockAndTintGetter;

        blockBuilder
                .useAtlas(BLOCK_ATLAS)
                .useBlockId(meshState.blockId())
                .useOffset(blockChunkOffset.x, blockChunkOffset.y, blockChunkOffset.z);

        for (class_777 quad : meshState.quads()) {
            int tint = 0xFFFFFFFF;
            if (quad.method_3360()) {
                tint = class_310.method_1551().method_1505().method_1697(mcState, level, mcPos, quad.method_3359());
                tint = 0xFF000000 | tint;
            }

            int[] vertices = quad.method_3357();
            for (int vertex = 0; vertex < 4; vertex++) {
                int offset = vertex * 8;
                blockBuilder
                        .addVertex(
                                Float.intBitsToFloat(vertices[offset]),
                                Float.intBitsToFloat(vertices[offset + 1]),
                                Float.intBitsToFloat(vertices[offset + 2])
                        )
                        .setTint(tint)
                        .setUv(
                                Float.intBitsToFloat(vertices[offset + 4]),
                                Float.intBitsToFloat(vertices[offset + 5])
                        );
            }
        }
    }
}
