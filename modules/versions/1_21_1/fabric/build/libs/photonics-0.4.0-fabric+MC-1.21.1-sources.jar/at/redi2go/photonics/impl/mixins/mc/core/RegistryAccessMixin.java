package at.redi2go.photonics.impl.mixins.mc.core;

import at.redi2go.photonics.api.mc.core.IRegistryAccess;
import net.minecraft.class_5455;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5455.class)
public interface RegistryAccessMixin extends IRegistryAccess {
}
