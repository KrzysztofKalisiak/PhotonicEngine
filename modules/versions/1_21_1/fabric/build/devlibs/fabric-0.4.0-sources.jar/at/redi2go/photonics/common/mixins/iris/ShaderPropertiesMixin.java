package at.redi2go.photonics.common.mixins.iris;

import at.redi2go.photonics.api.shaders.AlphaMode;
import at.redi2go.photonics.api.shaders.LightingMode;
import at.redi2go.photonics.common.iris.ShaderPropertiesBridge;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.irisshaders.iris.Iris;
import net.irisshaders.iris.helpers.StringPair;
import net.irisshaders.iris.shaderpack.properties.ShaderProperties;
import net.irisshaders.iris.shaderpack.option.ShaderPackOptions;
import net.irisshaders.iris.shaderpack.preprocessor.PropertiesPreprocessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;
import java.io.StringReader;
import java.util.Locale;
import java.util.Properties;
import java.util.function.Consumer;

import static at.redi2go.photonics.api.shaders.PhotonicsProperties.ALPHA_MODE_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.ENABLED_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.ENCHANTMENT_GLINT_STRENGTH_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.IS_BLOCK_LIGHT_ENABLED_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.IS_BLOCK_LIGHT_GI_ENABLED_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.IS_GI_ENABLED_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.IS_HANDHELD_LIGHT_ENABLED_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.IS_LIGHT_BINNING_ENABLED_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.LIGHTING_MODE_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.MAX_GI_BOUNCES_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.MAX_LIGHTS_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.MAX_SAMPLES_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.RENDER_SCALE_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.RESTIR_ACCUMULATION_FRAMES_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.RESTIR_COMBINED_GI_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.RESTIR_DENOISER_PASSES_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.RESTIR_INITIAL_SAMPLES_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.RESTIR_SOFT_SHADOWS_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.RESTIR_SPATIAL_REUSE_RADIUS_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.RESTIR_SPATIAL_REUSE_SAMPLES_KEY;
import static at.redi2go.photonics.api.shaders.PhotonicsProperties.SEPARATE_HANDHELD_RAYS_KEY;

@Mixin(ShaderProperties.class)
public abstract class ShaderPropertiesMixin {
    @Inject(
            method = "<init>(Ljava/lang/String;Lnet/irisshaders/iris/shaderpack/option/ShaderPackOptions;Ljava/lang/Iterable;)V",
            at = @At("RETURN"),
            require = 0
    )
    private void initFromProperties(
            String source,
            ShaderPackOptions shaderPackOptions,
            Iterable<StringPair> environmentDefines,
            CallbackInfo ci
    ) {
        String propertiesSource = source;
        try {
            propertiesSource = PropertiesPreprocessor.preprocessSource(source, shaderPackOptions, environmentDefines);
        } catch (LinkageError | RuntimeException e) {
            Iris.logger.warn("Could not preprocess Photonics shader properties, parsing raw source instead", e);
        }

        Properties properties = new Properties();
        try {
            properties.load(new StringReader(propertiesSource));
        } catch (IOException e) {
            Iris.logger.warn("Could not parse Photonics shader properties", e);
            return;
        }

        for (var entry : properties.entrySet()) {
            handlePhotonicsDirective((String) entry.getKey(), (String) entry.getValue());
        }
    }

    @Unique
    private static void handlePhotonicsDirective(String key, String value) {
        var phProperties = ShaderPropertiesBridge.getProperties();

        handleBooleanDirective(key, value, ENABLED_KEY, e -> phProperties.enabled = e);
        handleFloatDirective(key, value, RENDER_SCALE_KEY, e -> phProperties.renderScale = e);

        handleNonZeroDirective(key, value, MAX_LIGHTS_KEY, e -> phProperties.maxLights = e);
        handleNonZeroDirective(key, value, MAX_GI_BOUNCES_KEY, e -> phProperties.maxGiBounces = e);

        handleAlphaModeDirective(key, value, ALPHA_MODE_KEY, e -> phProperties.alphaMode = e);
        handleFloatDirective(key, value, ENCHANTMENT_GLINT_STRENGTH_KEY, e -> phProperties.enchantmentGlintStrength = e);
        handleBooleanDirective(key, value, SEPARATE_HANDHELD_RAYS_KEY, e -> phProperties.useSeparateHandheldRays = e);
        handleBooleanDirective(key, value, IS_BLOCK_LIGHT_ENABLED_KEY, e -> phProperties.blockLightEnabled = e);
        handleBooleanDirective(key, value, IS_GI_ENABLED_KEY, e -> phProperties.giEnabled = e);
        handleBooleanDirective(key, value, IS_BLOCK_LIGHT_GI_ENABLED_KEY, e -> phProperties.blockLightGiEnabled = e);
        handleBooleanDirective(key, value, IS_HANDHELD_LIGHT_ENABLED_KEY, e -> phProperties.handheldLightEnabled = e);
        handleBooleanDirective(key, value, IS_LIGHT_BINNING_ENABLED_KEY, e -> phProperties.lightBinningEnabled = e);

        handleLightingModeDirective(key, value, LIGHTING_MODE_KEY, e -> phProperties.lightingMode = e);

        handleNonZeroDirective(key, value, MAX_SAMPLES_KEY, e -> phProperties.maxSamples = e);

        handleNonZeroDirective(key, value, RESTIR_INITIAL_SAMPLES_KEY, e -> phProperties.restirInitialSamples = e);
        handleUnsignedIntDirective(key, value, RESTIR_SPATIAL_REUSE_SAMPLES_KEY, e -> phProperties.restirSpatialReuseSamples = e);
        handleFloatDirective(key, value, RESTIR_SPATIAL_REUSE_RADIUS_KEY, e -> phProperties.restirRestirSpatialReuseRadius = e);
        handleNonZeroDirective(key, value, RESTIR_ACCUMULATION_FRAMES_KEY, e -> phProperties.restirAccumulationFrames = e);
        handleUnsignedIntDirective(key, value, RESTIR_DENOISER_PASSES_KEY, e -> phProperties.restirDenoiserPasses = e);
        handleBooleanDirective(key, value, RESTIR_SOFT_SHADOWS_KEY, e -> phProperties.restirSoftShadows = e);
        handleBooleanDirective(key, value, RESTIR_COMBINED_GI_KEY, e -> phProperties.restirCombinedGi = e);
    }

    @Unique
    private static void handleBooleanDirective(String key, String value, String expectedKey, BooleanConsumer handler) {
        if (expectedKey.equals(key)) {
            Boolean parsed = parseBooleanDirectiveValue(value, expectedKey);
            if (parsed == null)
                Iris.logger.warn("Unexpected value for boolean key " + key + " in shaders.properties: got " + value + ", but expected either true or false");
            else
                handler.accept(parsed);
        }
    }

    @Unique
    private static Boolean parseBooleanDirectiveValue(String value, String expectedKey) {
        if ("true".equals(value) || "1".equals(value))
            return true;

        if ("false".equals(value) || "0".equals(value))
            return false;

        if (ENABLED_KEY.equals(expectedKey) && "PHOTONICS_ENABLED".equals(value))
            return ShaderPropertiesBridge.getPhotonicsEnabledOption();

        return null;
    }


    @Unique
    private static boolean handleNonZeroDirective(String key, String value, String expectedKey, Consumer<Integer> handler) {
        if (!expectedKey.equals(key)) {
            return false;
        } else {
            try {
                int result = Integer.parseInt(value);
                if (result <= 0)
                    throw new NumberFormatException("Was less than or equal to 0");

                handler.accept(result);
            } catch (NumberFormatException var5) {
                Iris.logger.warn("Unexpected value for unsigned integer key " + key + " in shaders.properties: got " + value + ", but expected an unsigned integer");
            }

            return true;
        }
    }

    @Unique
    private static boolean handleUnsignedIntDirective(String key, String value, String expectedKey, Consumer<Integer> handler) {
        if (!expectedKey.equals(key)) {
            return false;
        } else {
            try {
                int result = Integer.parseInt(value);
                if (result < 0)
                    throw new NumberFormatException("Was negative");

                handler.accept(result);
            } catch (NumberFormatException var5) {
                Iris.logger.warn("Unexpected value for unsigned integer key " + key + " in shaders.properties: got " + value + ", but expected an unsigned integer");
            }

            return true;
        }
    }

    @Unique
    private static boolean handleFloatDirective(String key, String value, String expectedKey, Consumer<Float> handler) {
        if (!expectedKey.equals(key)) {
            return false;
        } else {
            try {
                float result = Float.parseFloat(value);
                handler.accept(result);
            } catch (NumberFormatException var5) {
                Iris.logger.warn("Unexpected value for float key " + key + " in shaders.properties: got " + value + ", but expected a float");
            }

            return true;
        }
    }

    @Unique
    private static boolean handleAlphaModeDirective(String key, String value, String expectedKey, Consumer<AlphaMode> handler) {
        if (!expectedKey.equals(key)) {
            return false;
        } else {
            try {
                AlphaMode result = AlphaMode.valueOf(value.toUpperCase());

                handler.accept(result);
            } catch (IllegalArgumentException var5) {
                Iris.logger.warn("Unexpected value for alpha mode key " + key + " in shaders.properties: got " + value + ", but expected alpha mode");
            }

            return true;
        }
    }

    @Unique
    private static boolean handleLightingModeDirective(String key, String value, String expectedKey, Consumer<LightingMode> handler) {
        if (!expectedKey.equals(key)) {
            return false;
        } else {
            try {
                String normalizedValue = value.toUpperCase(Locale.ROOT);
                if ("SIMPLE".equals(normalizedValue))
                    normalizedValue = "BASIC";

                LightingMode result = LightingMode.valueOf(normalizedValue);

                handler.accept(result);
            } catch (IllegalArgumentException var5) {
                Iris.logger.warn("Unexpected value for lighting mode key " + key + " in shaders.properties: got " + value + ", but expected lighting mode");
            }

            return true;
        }
    }
}
