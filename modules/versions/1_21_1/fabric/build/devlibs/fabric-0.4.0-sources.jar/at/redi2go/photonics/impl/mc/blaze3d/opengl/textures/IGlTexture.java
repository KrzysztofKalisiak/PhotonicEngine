package at.redi2go.photonics.impl.mc.blaze3d.opengl.textures;

public interface IGlTexture {
    int handle();
}
